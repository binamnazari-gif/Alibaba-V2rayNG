package com.v2ray.ang.ui.main

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.dto.ConnectionTestResult
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.dto.LocateTarget
import com.v2ray.ang.dto.RealPingResult
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.ServersCache
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.extension.delay
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.matchesPattern
import com.v2ray.ang.extension.moveItem
import com.v2ray.ang.handler.SubscriptionInfoParser
import com.v2ray.ang.handler.StrictVerificationManager
import com.v2ray.ang.handler.UpdateCheckerManager
import com.v2ray.ang.ui.base.BaseViewModel
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.NetworkTypeHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.PatternSyntaxException

private fun applyTestDelayResults(
    servers: List<ServersCache>,
    updates: Map<String, RealPingResult>,
): List<ServersCache> = servers.map { server ->
    val res = updates[server.guid] ?: return@map server
    server.copy(
        testDelayMillis = res.delayMillis,
        affiliation = res.affiliationInfo ?: server.affiliation?.copy(testDelayMillis = res.delayMillis)
    )
}

private fun applyTestDelayResultsToRows(
    rows: List<ServerRowUiModel>,
    updates: Map<String, RealPingResult>,
): List<ServerRowUiModel> = rows.map { row ->
    val res = updates[row.guid] ?: return@map row
    row.copy(
        testDelayMillis = res.delayMillis,
        affiliation = res.affiliationInfo ?: row.affiliation?.copy(testDelayMillis = res.delayMillis)
    )
}

class MainViewModel(
    application: Application,
    private val dataSource: MainDataSource
) : BaseViewModel(application) {

    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    private val defaultDispatcher: CoroutineDispatcher = Dispatchers.Default
    private val preloadDispatcher: CoroutineDispatcher = Dispatchers.IO.limitedParallelism(1)

    // ---------- UI state ----------
    private val _uiState = MutableStateFlow(
        MainUiState(
            selectedGroupId = dataSource.getSelectedSubscriptionId(),
            selectedGuid = dataSource.getSelectServer(),
            confirmRemove = dataSource.getConfirmRemove(),
            doubleColumnDisplay = dataSource.getDoubleColumnDisplay()
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // ---------- Keyword filtering ----------
    @Volatile
    private var keywordFilter: String = ""
    private var filterJob: Job? = null

    // ---------- Groups & cache ----------
    private val cacheMutex = Mutex()
    private val groupDataCache = mutableMapOf<String, List<ServersCache>>()
    private val groupUiFlows = ConcurrentHashMap<String, MutableStateFlow<ServerGroupUiState>>()
    private val groupServerFlows = ConcurrentHashMap<String, StateFlow<List<ServersCache>>>()
    private val groupLoadMutexes = ConcurrentHashMap<String, Mutex>()
    private val serverOrderPersistenceJobs = mutableMapOf<String, Job>()

    private var setupGroupJob: Job? = null
    private var preloadJob: Job? = null
    private var selectedGroupLoadJob: Job? = null
    private var reloadJob: Job? = null
    private var testResultFlushJob: Job? = null
    private val pendingTestResults = linkedMapOf<String, RealPingResult>()

    private val testRequests = MainTestRequests()
    private var bulkTestJob: Job? = null

    private val initialPageReady = CompletableDeferred<Unit>()

    // ---------- Service events ----------
    init {
        collectServiceEvents()
        setupGroupTab()
    }

    private fun collectServiceEvents() {
        viewModelScope.launch {
            dataSource.mainServiceEvent.collect { event ->
                handleServiceEvent(event)
            }
        }
    }

    private fun handleServiceEvent(event: MainServiceEvent) {
        when (event) {
            MainServiceEvent.StateRunning -> {
                updateRunningState(true, clearTestingText = false)
                launchIdleBackgroundAudit()
            }
            MainServiceEvent.StateNotRunning -> {
                updateRunningState(false, clearTestingText = false)
                launchIdleBackgroundAudit()
            }
            MainServiceEvent.StateStartSuccess -> {
                toastSuccess(R.string.toast_services_success)
                updateRunningState(true)
                launchIdleBackgroundAudit()
            }

            is MainServiceEvent.StateStartFailure -> {
                if (!event.message.isNullOrBlank()) {
                    toastError(event.message)
                } else {
                    toastError(R.string.toast_services_failure)
                }
                updateRunningState(false)
            }

            MainServiceEvent.StateStopSuccess -> updateRunningState(false)
            is MainServiceEvent.TrafficSpeed -> {
                if (uiState.value.isRunning) {
                    _uiState.update { it.copy(liveTrafficSpeed = event.speedText) }
                }
            }
            is MainServiceEvent.MeasureDelayResult -> {
                if (!uiState.value.isRunning) return
                _uiState.update { it.copy(isTesting = false, status = MainStatus.ConnectionTest(event.result)) }
            }

            is MainServiceEvent.MeasureConfigSuccess -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                queueTestResult(event.result, request)
            }

            is MainServiceEvent.MeasureConfigNotify -> {
                if (event.requestId == testRequests.bulk?.id) {
                    _uiState.update { it.copy(status = MainStatus.TestProgress(event.progress)) }
                }
            }

            is MainServiceEvent.MeasureConfigFinish -> {
                val request = testRequests.bulk?.takeIf { it.id == event.requestId } ?: return
                val scheduledFlush = testResultFlushJob
                testResultFlushJob = viewModelScope.launch {
                    scheduledFlush?.cancelAndJoin()
                    if (testRequests.bulk?.id != request.id) return@launch
                    flushPendingTestResults(request)
                    onTestsFinished(request.id)
                }
            }

            is MainServiceEvent.MeasureDelayCancelled -> {
                //if (testRequests.completeCurrent(event.requestId)) resetTestStatus()
            }

            is MainServiceEvent.MeasureConfigCancelled -> {
                if (testRequests.completeBulk(event.requestId) != null) {
                    cancelPendingTestResults()
                    resetTestStatus()
                }
            }
        }
    }

    private fun queueTestResult(result: RealPingResult, request: MainTestRequests.Bulk) {
        pendingTestResults[result.guid] = result
        if (testResultFlushJob?.isActive == true) return

        testResultFlushJob = viewModelScope.launch {
            while (pendingTestResults.isNotEmpty()) {
                delay(TEST_RESULT_FLUSH_INTERVAL_MS)
                flushPendingTestResults(request)
            }
        }
    }

    private suspend fun flushPendingTestResults(request: MainTestRequests.Bulk) {
        if (pendingTestResults.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return

        val updates = cacheMutex.withLock {
            val drained = pendingTestResults.toMap()
            pendingTestResults.clear()
            groupDataCache[request.groupId]?.let { cached ->
                groupDataCache[request.groupId] = applyTestDelayResults(cached, drained)
            }
            drained
        }
        if (updates.isEmpty()) return
        if (testRequests.bulk?.id != request.id) return
        val cachedAll = cacheMutex.withLock { groupDataCache[request.groupId] }
        if (cachedAll != null) {
            updateGroupUi(request.groupId, cachedAll)
        } else {
            mutableServerGroupState(request.groupId).update { current ->
                current.copy(
                    servers = applyTestDelayResults(current.servers, updates),
                    rows = applyTestDelayResultsToRows(current.rows, updates),
                )
            }
        }
    }

    internal fun formatStatus(status: MainStatus): String = when (status) {
        MainStatus.Disconnected -> dataSource.getString(R.string.connection_not_connected)
        MainStatus.Connected -> dataSource.getString(R.string.connection_connected)
        MainStatus.Testing -> dataSource.getString(R.string.connection_test_testing)
        is MainStatus.TestProgress -> dataSource.getString(
            R.string.connection_running_task_left,
            status.progress
        )

        is MainStatus.ConnectionTest -> formatConnectionTestResult(status.result)
    }

    private fun formatConnectionTestResult(result: ConnectionTestResult): String {
        val status = if (result.delayMillis >= 0) {
            val delay = dataSource.getString(R.string.server_test_delay_value, result.delayMillis)
            dataSource.getString(R.string.connection_test_available, delay)
        } else {
            val detail = result.errorMessage.ifBlank {
                dataSource.getString(R.string.connection_test_empty_message)
            }
            dataSource.getString(R.string.connection_test_error, detail)
        }

        if (result.delayMillis < 0 || (result.country == null && result.ipAddress == null)) {
            return status
        }

        val unknown = dataSource.getString(R.string.value_unknown)
        return "$status\n(${result.country ?: unknown}) ${result.ipAddress ?: unknown}"
    }

    // ---------- Public state accessors ----------
    fun serversForGroup(groupId: String): StateFlow<List<ServersCache>> =
        groupServerFlows.computeIfAbsent(groupId) {
            val groupState = mutableServerGroupState(groupId)
            groupState
                .map { it.servers }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(stopTimeoutMillis = 5_000),
                    initialValue = groupState.value.servers,
                )
        }

    internal fun serverGroupState(groupId: String): StateFlow<ServerGroupUiState> =
        mutableServerGroupState(groupId).asStateFlow()

    private fun mutableServerGroupState(groupId: String): MutableStateFlow<ServerGroupUiState> =
        groupUiFlows.computeIfAbsent(groupId) { MutableStateFlow(ServerGroupUiState()) }

    private fun currentServers(): List<ServersCache> =
        mutableServerGroupState(uiState.value.selectedGroupId).value.servers

    // ---------- Action handler ----------
    fun onAction(action: MainAction) {
        when (action) {
            MainAction.Initialize -> initialize()
            MainAction.RefreshGroups -> setupGroupTab(forceRefresh = true)
            MainAction.TestAllServers -> testAllRealPing(true)
            MainAction.TestRealAllServers -> testAllRealPing()
            MainAction.StrictAuditAllServers -> testAllRealPing(onlyTcp = false, strictAudit = true)
            MainAction.SortByStrictScore -> sortByStrictScoreAsync()
            is MainAction.SelectCountryFilter -> selectCountryFilter(action.countryFilter)
            MainAction.CancelTesting -> cancelAllPing()
            MainAction.RemoveAllServers -> removeAllServerAsync()
            MainAction.RemoveDuplicateServers -> removeDuplicateServerAsync()
            MainAction.RemoveInvalidServers -> removeInvalidServerAsync()
            MainAction.SortByTestResults -> sortByTestResultsAsync()
            MainAction.UpdateSubscriptions -> importConfigViaSub(uiState.value.selectedGroupId)
            is MainAction.UpdateGroupSubscription -> importConfigViaSub(action.groupId)
            MainAction.ExportAll -> exportAllAsync()
            is MainAction.SelectGroup -> subscriptionIdChanged(action.groupId)
            is MainAction.SelectServer -> updateSelectedGuid(action.guid)
            is MainAction.RemoveServer -> removeServerAndRefresh(action.guid)
            is MainAction.Search -> filterConfig(action.query)
            is MainAction.ImportBatchConfig -> importBatchConfig(action.configText)
            is MainAction.CreateGroup -> createGroupAsync(action.name)
            is MainAction.DeleteGroup -> deleteGroupAsync(action.groupId)
            MainAction.ReleaseKillSwitch -> {
                if (!uiState.value.isRunning) {
                    dataSource.sendMsg2Service(AppConfig.MSG_STATE_STOP, "")
                }
            }
            MainAction.LocateHandled -> consumeLocateTarget()
            is MainAction.ShareQRCode -> {
                val bitmap = dataSource.share2QRCode(action.guid)
                _uiState.update { it.copy(shareQRCodeBitmap = bitmap) }
            }

            MainAction.DismissQRCodeDialog -> {
                _uiState.update { it.copy(shareQRCodeBitmap = null) }
            }

            MainAction.DismissUpdateDialog -> {
                _uiState.update { it.copy(availableUpdate = null) }
            }

            MainAction.ToggleService,
            MainAction.SmartConnect,
            MainAction.AutoDoubleVpn,
            MainAction.EditDoubleVpn,
            MainAction.TestCurrentServer,
            MainAction.ImportQRcode,
            MainAction.ImportClipboard,
            MainAction.ImportConfigLocal,
            is MainAction.ImportManually,
            MainAction.RestartService,
            MainAction.LocateSelectedServer,
            is MainAction.EditServer,
            is MainAction.ShareClipboard,
            is MainAction.ShareFullContent,
            is MainAction.OpenSubscriptionLink -> {
                // Handled by Activity via its onAction lambda
            }
        }
    }

    // ---------- Initialization ----------
    fun initialize() {
        viewModelScope.launch(preloadDispatcher) {
            try {
                initialPageReady.await()
                delay(32)
                dataSource.initAssets()
                dataSource.syncSubscriptions()
                runCatching {
                    val update = UpdateCheckerManager.checkForUpdate(includePreRelease = false)
                    if (update.hasUpdate && !update.downloadUrl.isNullOrBlank()) {
                        _uiState.update { it.copy(availableUpdate = update) }
                    }
                }
                launchIdleBackgroundAudit()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Main background initialization failed", error)
            }
        }
    }

    fun refreshUiSettings() {
        _uiState.update {
            it.copy(
                confirmRemove = dataSource.getConfirmRemove(),
                doubleColumnDisplay = dataSource.getDoubleColumnDisplay()
            )
        }
    }

    // ---------- Group & server loading ----------
    private suspend fun buildServersCache(guids: List<String>): List<ServersCache> =
        guids.distinct().mapNotNull { guid ->
            currentCoroutineContext().ensureActive()
            val profile = dataSource.decodeServerConfig(guid) ?: return@mapNotNull null
            val rawAff = dataSource.decodeAffiliationInfo(guid)
            val affiliation = if (rawAff?.countryCode.isNullOrBlank()) {
                val guessed = StrictVerificationManager.guessCountryCodeFromRemarks(profile.remarks)
                if (!guessed.isNullOrBlank()) {
                    (rawAff ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()).copy(
                        countryCode = guessed,
                        countryName = StrictVerificationManager.countryDisplayName(guessed)
                    )
                } else rawAff
            } else rawAff
            ServersCache(
                guid = guid,
                profile = profile.copy(),
                testDelayMillis = affiliation?.testDelayMillis ?: 0L,
                affiliation = affiliation
            )
        }

    private suspend fun loadGroup(
        groupId: String,
        forceRefresh: Boolean = false
    ): List<ServersCache> {
        val loadMutex = groupLoadMutexes.computeIfAbsent(groupId) { Mutex() }
        return loadMutex.withLock {
            if (!forceRefresh) {
                cacheMutex.withLock { groupDataCache[groupId]?.let { return@withLock it } }
            }
            val servers = buildServersCache(dataSource.getServerGuidList(groupId))
            currentCoroutineContext().ensureActive()
            cacheMutex.withLock { groupDataCache[groupId] = servers }
            servers
        }
    }

    private fun applyKeywordFilter(servers: List<ServersCache>): List<ServersCache> {
        val keyword = keywordFilter.trim()
        if (keyword.isEmpty()) return servers
        val regex = try {
            Regex(keyword, RegexOption.IGNORE_CASE)
        } catch (_: PatternSyntaxException) {
            return servers
        }
        return servers.filter { cache ->
            val profile = cache.profile
            profile.remarks.matchesPattern(regex, keyword) ||
                    profile.description.orEmpty().matchesPattern(regex, keyword) ||
                    profile.server.orEmpty().matchesPattern(regex, keyword) ||
                    profile.configType.name.matchesPattern(regex, keyword)
        }
    }

    private fun updateGroupUi(groupId: String, servers: List<ServersCache>) {
        val keywordFiltered = applyKeywordFilter(servers)
        val countries = keywordFiltered
            .mapNotNull { it.affiliation?.countryCode?.takeIf { c -> c.isNotBlank() && c != "IR" } }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key to it.value }
        val verifiedCount = keywordFiltered.count {
            it.affiliation?.strictVerified == true && it.affiliation?.geminiOk == true
        }
        val activeFilter = _uiState.value.selectedCountryFilter
        val baseFiltered = when (activeFilter) {
            "" -> keywordFiltered
            "__GEMINI_OK__" -> keywordFiltered.filter {
                it.affiliation?.strictVerified == true && it.affiliation?.geminiOk == true
            }
            else -> keywordFiltered.filter {
                it.affiliation?.countryCode.equals(activeFilter, ignoreCase = true)
            }
        }
        val hasAnyTestResult = baseFiltered.any {
            it.testDelayMillis != 0L || (it.affiliation?.lastAuditTime ?: 0L) > 0L
        }
        val filteredServers = if (hasAnyTestResult) {
            if (activeFilter.isEmpty()) {
                // In "All" tab: works for BOTH Delay/TCPing tests and Strict Audit!
                // Active servers (>0ms) always on top ranked by speed & lowest ping,
                // untested (0ms) in middle, dead/failed (-1ms) strictly at the very bottom.
                baseFiltered.sortedWith(
                    compareBy<ServersCache> {
                        when {
                            it.testDelayMillis > 0L -> 0
                            it.testDelayMillis == 0L -> 1
                            else -> 2
                        }
                    }
                        .thenByDescending { (it.affiliation?.downloadMbps ?: 0.0) >= 0.5 }
                        .thenBy {
                            val d = it.testDelayMillis
                            if (d > 0L) d else Long.MAX_VALUE
                        }
                        .thenByDescending { it.affiliation?.downloadMbps ?: 0.0 }
                )
            } else {
                // In "Verified" & Country tabs: rank by Strict Audit score
                baseFiltered.sortedWith(
                    compareByDescending<ServersCache> { it.affiliation?.strictVerified == true }
                            .thenByDescending { it.affiliation?.geminiOk == true }
                        .thenBy { it.affiliation?.isWarp == true }
                        .thenByDescending { it.affiliation?.downloadMbps ?: 0.0 }
                        .thenBy {
                            val d = it.testDelayMillis
                            when {
                                d > 0L -> d
                                d == 0L -> Long.MAX_VALUE - 1L
                                else -> Long.MAX_VALUE
                            }
                        }
                )
            }
        } else {
            baseFiltered
        }
        mutableServerGroupState(groupId).value = ServerGroupUiState(
            servers = filteredServers,
            rows = buildServerRows(groupId, filteredServers),
            availableCountries = countries,
            verifiedCount = verifiedCount,
        )
    }

    private fun selectCountryFilter(countryFilter: String) {
        if (_uiState.value.selectedCountryFilter == countryFilter) return
        _uiState.update { it.copy(selectedCountryFilter = countryFilter) }
        viewModelScope.launch(defaultDispatcher) {
            val snapshot = cacheMutex.withLock { groupDataCache.toMap() }
            snapshot.forEach { (groupId, servers) ->
                updateGroupUi(groupId, servers)
            }
        }
    }

    private fun sortByStrictScoreAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val groupId = uiState.value.selectedGroupId
                    val subs = if (groupId.isEmpty()) dataSource.getSubsList() else listOf(groupId)
                    subs.forEach { subId ->
                        val guids = dataSource.getServerGuidList(subId)
                        val sorted = guids.sortedWith(
                            compareByDescending<String> { g ->
                                dataSource.decodeAffiliationInfo(g)?.strictVerified == true
                            }.thenByDescending { g ->
                                dataSource.decodeAffiliationInfo(g)?.geminiOk == true
                            }.thenByDescending { g ->
                                dataSource.decodeAffiliationInfo(g)?.downloadMbps ?: 0.0
                            }.thenBy { g ->
                                val d = dataSource.decodeAffiliationInfo(g)?.testDelayMillis ?: 0L
                                if (d <= 0L) Long.MAX_VALUE else d
                            }
                        )
                        dataSource.encodeServerList(sorted, subId)
                    }
                    cacheMutex.withLock { groupDataCache.clear() }
                    setupGroupTab(forceRefresh = true)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Strict sort failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun buildServerRows(groupId: String, servers: List<ServersCache>): List<ServerRowUiModel> {
        val subscriptionRemarks = if (groupId.isEmpty()) {
            servers.asSequence()
                .map { it.profile.subscriptionId }
                .filter { it.isNotEmpty() }
                .distinct()
                .associateWith { subscriptionId ->
                    dataSource.getSubscriptionItem(subscriptionId)?.remarks.orEmpty()
                }
        } else {
            emptyMap()
        }
        return servers.map { server ->
            buildServerRowUiModel(
                server = server,
                subscriptionRemarks = subscriptionRemarks[server.profile.subscriptionId].orEmpty()
            )
        }
    }

    fun getSubscriptions(): List<SubscriptionCache> = dataSource.getSubscriptions()

    private fun resolveSelectedGroup(groups: List<GroupMapItem>): String {
        val current = uiState.value.selectedGroupId
        val resolved = when {
            groups.isEmpty() -> ""
            groups.any { it.id == current } -> current
            else -> groups.first().id
        }
        if (resolved != current) {
            dataSource.setSelectedSubscriptionId(resolved)
        }
        return resolved
    }

    private fun radialPreloadOrder(groups: List<GroupMapItem>, selectedIndex: Int): List<String> {
        if (groups.isEmpty()) return emptyList()
        val result = ArrayList<String>((groups.size - 1).coerceAtLeast(0))
        for (distance in 1 until groups.size) {
            val right = selectedIndex + distance
            val left = selectedIndex - distance
            if (right in groups.indices) result += groups[right].id
            if (left in groups.indices) result += groups[left].id
        }
        return result
    }

    fun setupGroupTab(forceRefresh: Boolean = false): Job {
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()

        return viewModelScope.launch(ioDispatcher) {
            try {
                if (forceRefresh) {
                    cacheMutex.withLock { groupDataCache.clear() }
                }
                val groups = dataSource.getSubscriptions().map {
                    GroupMapItem(
                        id = it.guid,
                        remarks = it.subscription.remarks,
                        usageInfo = it.subscription.usageInfo?.let { info ->
                            SubscriptionInfoParser.withWebPageFallback(info, it.subscription.url)
                        },
                    )
                }
                val selectedGroup = resolveSelectedGroup(groups)
                val validIds = groups.mapTo(HashSet()) { it.id }
                groupUiFlows.keys.removeAll { it !in validIds }
                groupServerFlows.keys.removeAll { it !in validIds }
                groupLoadMutexes.keys.removeAll { it !in validIds }

                _uiState.update {
                    it.copy(
                        groups = groups,
                        selectedGroupId = selectedGroup,
                        selectedGuid = dataSource.getSelectServer(),
                        selectedServerLabel = resolveSelectedServerLabel(dataSource.getSelectServer()),
                    )
                }
                groups.forEach { mutableServerGroupState(it.id) }

                if (groups.isEmpty()) {
                    cacheMutex.withLock { groupDataCache.clear() }
                    return@launch
                }

                val selectedServers = loadGroup(selectedGroup, forceRefresh)
                updateGroupUi(selectedGroup, selectedServers)

                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }

                val selectedIndex =
                    groups.indexOfFirst { it.id == selectedGroup }.coerceAtLeast(0)
                val preloadOrder = radialPreloadOrder(groups, selectedIndex)
                preloadJob = viewModelScope.launch(preloadDispatcher) {
                    preloadOrder.forEach { groupId ->
                        ensureActive()
                        delay(32)
                        val servers = loadGroup(groupId, forceRefresh)
                        updateGroupUi(groupId, servers)
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to set up group tabs", error)
            } finally {
                if (!initialPageReady.isCompleted) {
                    initialPageReady.complete(Unit)
                }
            }
        }.also { setupGroupJob = it }
    }

    // ---------- Business actions (coroutine-based) ----------

    private fun deduplicateAndCleanGroup(groupId: String): Int {
        val guids = dataSource.getServerGuidList(groupId)
        val seen = HashSet<ProfileItem>()
        val toRemove = ArrayList<String>()
        guids.forEach { guid ->
            val profile = dataSource.decodeServerConfig(guid)
            if (profile == null) {
                toRemove += guid
            } else if (!profile.configType.isComplexType()) {
                val portOk = profile.serverPort?.toIntOrNull()?.let { it in 1..65535 } == true
                val hostOk = !profile.server.isNullOrBlank()
                if (!hostOk || !portOk) {
                    toRemove += guid
                } else {
                    val identity = profile.duplicateIdentity()
                    if (!seen.add(identity)) {
                        toRemove += guid
                    }
                }
            }
        }
        toRemove.forEach { dataSource.removeServer(it) }
        // Immediately categorize newly pasted configs by country (from flag/name in remarks)
        val remainingGuids = dataSource.getServerGuidList(groupId)
        remainingGuids.forEach { guid ->
            val profile = dataSource.decodeServerConfig(guid) ?: return@forEach
            val existingAff = dataSource.decodeAffiliationInfo(guid)
            if (existingAff?.countryCode.isNullOrBlank()) {
                val guessed = StrictVerificationManager.guessCountryCodeFromRemarks(profile.remarks)
                if (!guessed.isNullOrBlank()) {
                    val updated = (existingAff ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()).copy(
                        countryCode = guessed,
                        countryName = StrictVerificationManager.countryDisplayName(guessed)
                    )
                    com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(guid, updated)
                }
            }
        }
        return toRemove.size
    }

    private fun importBatchConfig(configText: String) {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val groupId = uiState.value.selectedGroupId
                    val (count, countSub) = dataSource.importBatchConfig(
                        configText, groupId, true
                    )
                    val removedAuto = if (count > 0) deduplicateAndCleanGroup(groupId) else 0
                    val netImported = (count - removedAuto).coerceAtLeast(0)
                    when {
                        count > 0 -> {
                            val msg = if (removedAuto > 0) {
                                dataSource.getString(R.string.title_import_config_count, netImported) +
                                    " (-$removedAuto dup/invalid)"
                            } else {
                                dataSource.getString(R.string.title_import_config_count, count)
                            }
                            toast(msg)
                            setupGroupTab(forceRefresh = true)
                            launchIdleBackgroundAudit()
                        }

                        countSub > 0 -> setupGroupTab(forceRefresh = true)
                        else -> toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Failed to import batch config", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun importConfigViaSub(subId: String) {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val result = if (subId.isEmpty()) {
                        dataSource.updateConfigViaSubAll()
                    } else {
                        val item = dataSource.getSubscriptionItem(subId) ?: return@withContext
                        dataSource.updateConfigViaSub(SubscriptionCache(subId, item))
                    }
                    when {
                        result.successCount + result.failureCount + result.skipCount == 0 ->
                            toast(R.string.title_update_subscription_no_subscription)

                        result.successCount > 0 && result.failureCount + result.skipCount == 0 ->
                            toast(
                                getQuantityString(
                                    R.plurals.title_update_config_count,
                                    result.configCount,
                                    result.configCount,
                                )
                            )

                        else ->
                            toast(dataSource.getString(R.string.title_update_subscription_result, result.configCount, result.successCount, result.failureCount, result.skipCount))
                    }
                    if (result.configCount > 0) {
                        setupGroupTab(forceRefresh = true)
                        refreshSelectedGuid()
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Subscription update failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun exportAllAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val groupId = uiState.value.selectedGroupId
                    val list = if (groupId.isEmpty() && keywordFilter.isEmpty()) {
                        dataSource.getServerGuidList("")
                    } else {
                        currentServers().map { it.guid }
                    }
                    val ret = dataSource.shareNonCustomConfigsToClipboard(list)
                    if (ret > 0) {
                        toast(dataSource.getString(R.string.title_export_config_count, ret))
                    } else {
                        toastError(R.string.toast_failure)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Export failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeAllServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count =
                        if (uiState.value.selectedGroupId.isEmpty() && keywordFilter.isEmpty()) {
                            dataSource.removeAllServer()
                        } else {
                            val guids = currentServers().map { it.guid }
                            guids.forEach { dataSource.removeServer(it) }
                            guids.size
                        }
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                    }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete all failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeDuplicateServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val seen = HashSet<ProfileItem>()
                    val duplicates = ArrayList<String>()
                    currentServers().forEach { server ->
                        val profile = server.profile
                        if (!profile.configType.isComplexType()) {
                            val identity = profile.duplicateIdentity()
                            if (!seen.add(identity)) duplicates += server.guid
                        }
                    }
                    duplicates.forEach { dataSource.removeServer(it) }
                    setupGroupTab(forceRefresh = true)
                    toast(dataSource.getString(R.string.title_del_duplicate_config_count, duplicates.size))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete duplicate failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    val count = removeInvalidServerInternal()
                    viewModelScope.launch(ioDispatcher) {
                        cacheMutex.withLock { groupDataCache.clear() }
                        setupGroupTab(forceRefresh = true)
                    }
                    toast(dataSource.getString(R.string.title_del_config_count, count))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Delete invalid failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun removeInvalidServerInternal(): Int {
        val visibleServersOnly =
            uiState.value.selectedGroupId.isNotEmpty() || keywordFilter.isNotBlank()
        return if (visibleServersOnly) {
            currentServers().sumOf { server ->
                dataSource.removeInvalidServerByGuid(server.guid)
            }
        } else {
            dataSource.removeInvalidServersInGroup("")
        }
    }

    private fun sortByTestResultsAsync() {
        launchLoading {
            withContext(ioDispatcher) {
                try {
                    sortByTestResultsInternal()
                    cacheMutex.withLock { groupDataCache.clear() }
                    setupGroupTab(forceRefresh = true)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    LogUtil.e(AppConfig.TAG, "Sort by test results failed", e)
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun sortByTestResultsInternal() {
        val subs = if (uiState.value.selectedGroupId.isEmpty()) {
            dataSource.getSubsList()
        } else {
            listOf(uiState.value.selectedGroupId)
        }
        subs.forEach { dataSource.sortByTestResultsForSub(it) }
    }

    fun subscriptionIdChanged(id: String) {
        if (_uiState.value.groups.none { it.id == id }) return
        mutableServerGroupState(id)
        if (uiState.value.selectedGroupId != id) {
            dataSource.setSelectedSubscriptionId(id)
            _uiState.update { it.copy(selectedGroupId = id) }
        }
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            try {
                updateGroupUi(id, loadGroup(id))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to load selected group: $id", error)
            }
        }
    }

    fun reloadServerList() {
        val groupId = uiState.value.selectedGroupId
        selectedGroupLoadJob?.cancel()
        selectedGroupLoadJob = viewModelScope.launch(ioDispatcher) {
            updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
        }
    }

    fun reloadAllGroups(groupIds: List<String>) {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch(preloadDispatcher) {
            val selected = uiState.value.selectedGroupId
            val order = buildList {
                if (selected in groupIds) add(selected)
                addAll(groupIds.filter { it != selected })
            }
            order.forEachIndexed { index, groupId ->
                ensureActive()
                if (index > 0) delay(32)
                updateGroupUi(groupId, loadGroup(groupId, forceRefresh = true))
            }
        }
    }

    fun filterConfig(keyword: String) {
        if (keyword == keywordFilter) return
        keywordFilter = keyword
        filterJob?.cancel()
        preScanJob?.cancel()
        filterJob = viewModelScope.launch(defaultDispatcher) {
            delay(300)
            val snapshot = cacheMutex.withLock { groupDataCache.toMap() }
            ensureActive()
            snapshot.forEach { (groupId, servers) ->
                ensureActive()
                updateGroupUi(groupId, servers)
            }
        }
    }


    private fun resolveSelectedServerLabel(guid: String?): String {
        if (guid.isNullOrBlank()) return ""
        val profile = dataSource.decodeServerConfig(guid) ?: return ""
        val aff = dataSource.decodeAffiliationInfo(guid)
        val flag = if (!aff?.countryCode.isNullOrBlank()) {
            "${StrictVerificationManager.countryFlag(aff?.countryCode)} [${aff?.countryCode}] "
        } else ""
        return flag + profile.remarks
    }

    private fun createGroupAsync(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch(ioDispatcher) {
            val newId = dataSource.createGroup(trimmed)
            if (newId.isNotEmpty()) {
                dataSource.setSelectedSubscriptionId(newId)
            }
            cacheMutex.withLock { groupDataCache.clear() }
            setupGroupTab(forceRefresh = true)
        }
    }

    private fun deleteGroupAsync(groupId: String) {
        if (groupId.isEmpty()) return
        val realGroups = uiState.value.groups.filter { it.id.isNotEmpty() }
        if (realGroups.size <= 1) {
            toast(R.string.toast_action_not_allowed)
            return
        }
        viewModelScope.launch(ioDispatcher) {
            dataSource.deleteGroup(groupId)
            cacheMutex.withLock { groupDataCache.clear() }
            setupGroupTab(forceRefresh = true)
        }
    }




    private var preScanJob: Job? = null
    private val isLiveProbing = java.util.concurrent.atomic.AtomicBoolean(false)

    fun cancelIdleBackgroundAudit() {
        preScanJob?.cancel()
        preScanJob = null
    }

    /**
     * Continuous, ultra-gentle background Gemini & bidirectional auditor:
     * - Runs 1 server at a time across ALL untested configs in ALL tabs (even while connected!).
     * - Uses a calm 2.5s pause between servers when connected (~20 KB/s avg, imperceptible).
     * - Automatically pauses politely during manual bulk tests or live Smart/Double VPN probes.
     * - When connected, ONLY saves successful (downloadMbps > 0) results as verified so a broken
     *   active VPN can never falsely poison untested servers as dead.
     * - Updates the UI live whenever new Verified (Gemini OK) or bidirectional servers are found.
     */
    private fun launchIdleBackgroundAudit() {
        if (preScanJob?.isActive == true) return
        preScanJob = viewModelScope.launch(ioDispatcher) {
            try {
                delay(3000)
                while (true) {
                    currentCoroutineContext().ensureActive()
                    if (testRequests.isTesting || isLiveProbing.get()) {
                        delay(2000)
                        continue
                    }

                    val allGuids = dataSource.getServerGuidList("").distinct()
                    if (allGuids.isEmpty()) {
                        delay(15000)
                        continue
                    }

                    val nextCandidate = allGuids.firstOrNull { guid ->
                        val p = dataSource.decodeServerConfig(guid) ?: return@firstOrNull false
                        if (p.configType.isComplexType()
                            || p.configType == com.v2ray.ang.enums.EConfigType.WIREGUARD
                        ) return@firstOrNull false
                        val aff = dataSource.decodeAffiliationInfo(guid)
                        (aff?.lastAuditTime ?: 0L) == 0L
                    }

                    if (nextCandidate == null) {
                        delay(30000)
                        continue
                    }

                    val profile = dataSource.decodeServerConfig(nextCandidate)
                    if (profile == null) {
                        delay(500)
                        continue
                    }

                    val connectedNow = uiState.value.isRunning

                    if (!connectedNow) {
                        val host = profile.server?.takeIf { it.isNotBlank() }
                        val port = profile.serverPort?.toIntOrNull()?.takeIf { it in 1..65535 }
                        if (host != null && port != null && profile.configType != com.v2ray.ang.enums.EConfigType.HYSTERIA2) {
                            val tcp = com.v2ray.ang.handler.SpeedtestManager.socketConnectTime(host, port, 900)
                            if (tcp <= -1L) {
                                val dead = (dataSource.decodeAffiliationInfo(nextCandidate)
                                    ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()).copy(
                                    testDelayMillis = -1L,
                                    downloadMbps = 0.0,
                                    lastAuditTime = System.currentTimeMillis()
                                )
                                com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(nextCandidate, dead)
                                continue
                            }
                        }
                    }

                    if (testRequests.isTesting || isLiveProbing.get()) {
                        delay(1500)
                        continue
                    }

                    var shouldRefreshUi = false
                    runCatching {
                        val info = StrictVerificationManager.auditServer(app, nextCandidate)
                        val stillConnected = uiState.value.isRunning
                        if (info.downloadMbps > 0.0 && info.testDelayMillis > 0L) {
                            com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(nextCandidate, info)
                            shouldRefreshUi = true
                        } else if (!stillConnected) {
                            com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(nextCandidate, info)
                        } else {
                            val prev = dataSource.decodeAffiliationInfo(nextCandidate)
                                ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()
                            com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(
                                nextCandidate,
                                prev.copy(lastAuditTime = System.currentTimeMillis())
                            )
                        }
                    }

                    if (shouldRefreshUi && !testRequests.isTesting && !isLiveProbing.get()) {
                        cacheMutex.withLock { groupDataCache.clear() }
                        reloadAllGroups(_uiState.value.groups.map { it.id })
                    }

                    delay(if (uiState.value.isRunning) 2500 else 800)
                }
            } catch (_: CancellationException) {
                // ignore
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "Background Gemini audit failed", e)
            }
        }
    }

    /**
     * Fast 16-thread TCP pre-filter across ALL 500+ configs so live probes never waste time
     * on dead ports and always reach working servers deep in the list.
     */
    private fun filterTcpReachableFast(
        candidates: List<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo?>>,
        maxLiveNeeded: Int = 36,
        maxScanPool: Int = 180
    ): List<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo?>> {
        val slice = candidates.take(maxScanPool)
        if (slice.isEmpty()) return emptyList()
        val tcpPool = java.util.concurrent.Executors.newFixedThreadPool(16)
        val alive = mutableListOf<Pair<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo?>, Long>>()
        try {
            for (batch in slice.chunked(32)) {
                val futures = batch.map { item ->
                    item to tcpPool.submit<Long> {
                        val prof = item.second
                        if (prof.configType == com.v2ray.ang.enums.EConfigType.HYSTERIA2) return@submit 100L
                        val host = prof.server?.takeIf { it.isNotBlank() } ?: return@submit -1L
                        val port = prof.serverPort?.toIntOrNull()?.takeIf { it in 1..65535 } ?: return@submit -1L
                        com.v2ray.ang.handler.SpeedtestManager.socketConnectTime(host, port, 850)
                    }
                }
                for ((item, f) in futures) {
                    val ms = runCatching { f.get(1200, java.util.concurrent.TimeUnit.MILLISECONDS) }.getOrDefault(-1L)
                    if (ms > 0L) {
                        alive.add(item to ms)
                    }
                }
                if (alive.size >= maxLiveNeeded) break
            }
        } finally {
            tcpPool.shutdownNow()
        }
        return alive.sortedBy { it.second }.map { it.first }
    }

    /**
     * Live parallel bidirectional finder for Smart Connect:
     * Scans across ALL 500+ untried configs (fast TCP filter -> parallel 32KB download probes)
     * and returns ONLY a server that ACTUALLY passes both Upload + Download right now.
     */
    private fun findLiveBidirectionalCandidate(
        allCandidates: List<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo?>>,
        triedGuids: MutableSet<String>
    ): Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo>? {
        val untried = allCandidates.filter { it.first !in triedGuids }
        if (untried.isEmpty()) return null

        val liveTcp = filterTcpReachableFast(untried, maxLiveNeeded = 36, maxScanPool = 200)
        if (liveTcp.isEmpty()) return null

        val pool = java.util.concurrent.Executors.newFixedThreadPool(6)
        try {
            for (wave in liveTcp.chunked(6)) {
                val futures = wave.map { item ->
                    item to pool.submit<Pair<Long, Double>?> {
                        StrictVerificationManager.quickBidirectionalProbe(app, item.first)
                    }
                }
                val winners = mutableListOf<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo>>()
                val now = System.currentTimeMillis()
                for ((item, future) in futures) {
                    val res = runCatching { future.get(6500, java.util.concurrent.TimeUnit.MILLISECONDS) }.getOrNull()
                    val prev = item.third ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()
                    if (res != null && res.second > 0.0) {
                        val updated = prev.copy(
                            testDelayMillis = res.first,
                            downloadMbps = res.second,
                            lastAuditTime = now
                        )
                        com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(item.first, updated)
                        winners.add(Triple(item.first, item.second, updated))
                    } else {
                        val failed = prev.copy(downloadMbps = 0.0, lastAuditTime = now)
                        com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(item.first, failed)
                        triedGuids.add(item.first)
                    }
                }
                if (winners.isNotEmpty()) {
                    return winners.maxByOrNull { (_, _, aff) ->
                        (aff.downloadMbps * 1000.0) - (aff.testDelayMillis * 0.5)
                    }
                }
            }
        } finally {
            pool.shutdownNow()
        }
        return null
    }

    /**
     * Live parallel FULL-CHAIN bidirectional finder for Double VPN:
     * Actually boots Entry -> Exit (e.g. V2Ray -> WireGuard) and downloads real bytes through
     * BOTH hops, rejecting any Entry that yields DL 0.0 B/s when chained with WireGuard!
     */
    private fun findLiveDoubleVpnEntry(
        allEntryCandidates: List<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo?>>,
        exitRemarks: String,
        triedGuids: MutableSet<String>
    ): Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo>? {
        val untried = allEntryCandidates.filter { it.first !in triedGuids }
        if (untried.isEmpty()) return null

        val liveTcp = filterTcpReachableFast(untried, maxLiveNeeded = 28, maxScanPool = 200)
        if (liveTcp.isEmpty()) return null

        val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
        try {
            for (wave in liveTcp.chunked(4)) {
                val futures = wave.map { item ->
                    item to pool.submit<Pair<Long, Double>?> {
                        StrictVerificationManager.quickChainBidirectionalProbe(app, item.second.remarks, exitRemarks)
                    }
                }
                val winners = mutableListOf<Triple<String, ProfileItem, com.v2ray.ang.dto.entities.ServerAffiliationInfo>>()
                val now = System.currentTimeMillis()
                for ((item, future) in futures) {
                    val res = runCatching { future.get(8000, java.util.concurrent.TimeUnit.MILLISECONDS) }.getOrNull()
                    val prev = item.third ?: com.v2ray.ang.dto.entities.ServerAffiliationInfo()
                    if (res != null && res.second > 0.0) {
                        val updated = prev.copy(
                            testDelayMillis = res.first,
                            downloadMbps = res.second,
                            lastAuditTime = now
                        )
                        com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(item.first, updated)
                        doubleVpnVerifiedEntryTimestamps[item.first] = now
                        winners.add(Triple(item.first, item.second, updated))
                    } else {
                        val failed = prev.copy(downloadMbps = 0.0, lastAuditTime = now)
                        com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(item.first, failed)
                        doubleVpnVerifiedEntryTimestamps.remove(item.first)
                        triedGuids.add(item.first)
                    }
                }
                if (winners.isNotEmpty()) {
                    return winners.maxByOrNull { (_, _, aff) ->
                        (aff.downloadMbps * 1000.0) - (aff.testDelayMillis * 0.5)
                    }
                }
            }
        } finally {
            pool.shutdownNow()
        }
        return null
    }

    private val doubleVpnVerifiedEntryTimestamps = ConcurrentHashMap<String, Long>()
    private val FRESH_BIDIR_WINDOW_MS = 5L * 60L * 1000L

    fun hasCachedBidirectionalServer(forDoubleVpn: Boolean = false): Boolean {
        val now = System.currentTimeMillis()
        val tried = if (forDoubleVpn) doubleVpnTriedEntries else smartConnectTriedGuids
        return dataSource.getServerGuidList("").any { guid ->
            if (guid in tried) return@any false
            val prof = dataSource.decodeServerConfig(guid) ?: return@any false
            if (prof.configType.isComplexType()) return@any false
            if (forDoubleVpn) {
                if (prof.configType == com.v2ray.ang.enums.EConfigType.WIREGUARD) return@any false
                val chainTs = doubleVpnVerifiedEntryTimestamps[guid] ?: 0L
                chainTs > 0L && (now - chainTs) < FRESH_BIDIR_WINDOW_MS
            } else {
                val aff = dataSource.decodeAffiliationInfo(guid)
                aff != null &&
                    aff.testDelayMillis > 0L &&
                    aff.downloadMbps > 0.0 &&
                    (now - aff.lastAuditTime) < FRESH_BIDIR_WINDOW_MS
            }
        }
    }

    fun findDoubleVpnGuid(): String? {
        return dataSource.getServerGuidList("").firstOrNull { guid ->
            val p = dataSource.decodeServerConfig(guid)
            p?.configType == com.v2ray.ang.enums.EConfigType.PROXYCHAIN &&
                p.remarks == "⚡ Ali baba Double VPN"
        }
    }

    private val doubleVpnTriedEntries = LinkedHashSet<String>()
    private var doubleVpnLastTapMs: Long = 0L

    fun createOrUpdateAutoDoubleVpn(): Pair<String, String>? {
        isLiveProbing.set(true)
        try {
            val now = System.currentTimeMillis()
            if (doubleVpnLastTapMs > 0L && (now - doubleVpnLastTapMs) > 3L * 60L * 60L * 1000L) {
                doubleVpnTriedEntries.clear()
            }
            doubleVpnLastTapMs = now

            val excluded = setOf(
                com.v2ray.ang.enums.EConfigType.CUSTOM,
                com.v2ray.ang.enums.EConfigType.CUSTOM_OUTBOUND,
                com.v2ray.ang.enums.EConfigType.POLICYGROUP,
                com.v2ray.ang.enums.EConfigType.PROXYCHAIN,
            )
            val allItems = dataSource.getServerGuidList("").distinct().mapNotNull { guid ->
                val profile = dataSource.decodeServerConfig(guid) ?: return@mapNotNull null
                if (profile.configType in excluded) return@mapNotNull null
                val aff = dataSource.decodeAffiliationInfo(guid)
                Triple(guid, profile, aff)
            }
            if (allItems.size < 2) return null

            val wgExits = allItems.filter { it.second.configType == com.v2ray.ang.enums.EConfigType.WIREGUARD }
            val verifiedExits = allItems.filter { it.third?.strictVerified == true && it.third?.geminiOk == true }
            val activeExits = allItems.filter { (it.third?.testDelayMillis ?: 0L) > 0L }
            val exit = when {
                wgExits.isNotEmpty() -> wgExits.first()
                verifiedExits.isNotEmpty() -> verifiedExits.maxByOrNull { (_, _, aff) ->
                    val nativeBonus = if (aff?.isWarp == false) 500.0 else 0.0
                    val speed = aff?.downloadMbps ?: 0.0
                    val delay = (aff?.testDelayMillis ?: 2500L).coerceIn(1L, 5000L)
                    nativeBonus + (speed * 1000.0) - (delay * 0.4)
                }!!
                activeExits.isNotEmpty() -> activeExits.minByOrNull { it.third?.testDelayMillis ?: Long.MAX_VALUE }!!
                else -> allItems.first()
            }

            val entryCandidates = allItems
                .filter {
                    it.first != exit.first &&
                        it.second.remarks != exit.second.remarks &&
                        it.second.configType != com.v2ray.ang.enums.EConfigType.WIREGUARD
                }
                .ifEmpty { allItems.filter { it.first != exit.first } }
            if (entryCandidates.isEmpty()) return null

            val rankedEntries = entryCandidates.sortedByDescending { (guid, prof, aff) ->
                val chainTs = doubleVpnVerifiedEntryTimestamps[guid] ?: 0L
                val isFreshChain = chainTs > 0L && (now - chainTs) < FRESH_BIDIR_WINDOW_MS
                val speed = aff?.downloadMbps ?: 0.0
                val delay = (aff?.testDelayMillis ?: 2500L).coerceIn(1L, 5000L)
                val freshBonus = if (isFreshChain) 5000.0 else 0.0
                val bidirBonus = if (speed > 0.0) 800.0 else 0.0
                val protoBonus = when (prof.configType) {
                    com.v2ray.ang.enums.EConfigType.VLESS -> if (prof.security.equals("reality", true)) 450.0 else 300.0
                    com.v2ray.ang.enums.EConfigType.TROJAN -> 300.0
                    com.v2ray.ang.enums.EConfigType.SHADOWSOCKS -> 180.0
                    else -> 0.0
                }
                freshBonus + bidirBonus + protoBonus + (speed * 1000.0) - (delay * 0.5)
            }

            val freshUntried = rankedEntries.firstOrNull { (guid, _, _) ->
                guid !in doubleVpnTriedEntries &&
                    (now - (doubleVpnVerifiedEntryTimestamps[guid] ?: 0L)) < FRESH_BIDIR_WINDOW_MS
            }

            var entry = freshUntried ?: findLiveDoubleVpnEntry(rankedEntries, exit.second.remarks, doubleVpnTriedEntries)
            if (entry == null && doubleVpnTriedEntries.isNotEmpty()) {
                doubleVpnTriedEntries.clear()
                entry = findLiveDoubleVpnEntry(rankedEntries, exit.second.remarks, doubleVpnTriedEntries)
            }
            if (entry == null) {
                return null
            }
            doubleVpnTriedEntries.add(entry.first)

            val existingGuid = findDoubleVpnGuid().orEmpty()
            val targetSubId = uiState.value.selectedGroupId.ifEmpty { AppConfig.DEFAULT_SUBSCRIPTION_ID }
            val chainProfile = ProfileItem.create(com.v2ray.ang.enums.EConfigType.PROXYCHAIN).apply {
                remarks = "⚡ Ali baba Double VPN"
                subscriptionId = targetSubId
                proxyChainProfileList = listOf(entry.second.remarks, exit.second.remarks)
                description = "${entry.second.remarks} → ${exit.second.remarks}"
            }
            val savedGuid = com.v2ray.ang.handler.MmkvManager.encodeServerConfig(existingGuid, chainProfile)
            entry.third?.let { verifiedAff ->
                com.v2ray.ang.handler.MmkvManager.encodeServerAffiliationInfo(savedGuid, verifiedAff)
            }
            updateSelectedGuid(savedGuid)
            setupGroupTab(forceRefresh = true)
            val dlTag = entry.third?.downloadMbps?.takeIf { it > 0.0 }?.let {
                " • ↓" + String.format(java.util.Locale.US, "%.1f", it) + " Mbps"
            }.orEmpty()
            return savedGuid to "#${doubleVpnTriedEntries.size}: ${entry.second.remarks} → ${exit.second.remarks}$dlTag"
        } finally {
            isLiveProbing.set(false)
        }
    }

    private val smartConnectTriedGuids = LinkedHashSet<String>()
    private var smartConnectLastTapMs: Long = 0L

    fun selectBestServerForSmartConnect(): Pair<String, String>? {
        isLiveProbing.set(true)
        try {
            val now = System.currentTimeMillis()
            if (smartConnectLastTapMs > 0L && (now - smartConnectLastTapMs) > 3L * 60L * 60L * 1000L) {
                smartConnectTriedGuids.clear()
            }
            smartConnectLastTapMs = now

            val censoredCountries = setOf("IR", "CN", "RU", "BY", "KP", "SY", "CU")
            val allGuids = dataSource.getServerGuidList("").distinct()
            if (allGuids.isEmpty()) return null

            val allEntries = allGuids.mapNotNull { guid ->
                val profile = dataSource.decodeServerConfig(guid) ?: return@mapNotNull null
                if (profile.configType.isComplexType()) return@mapNotNull null
                val aff = dataSource.decodeAffiliationInfo(guid)
                Triple(guid, profile, aff)
            }
            if (allEntries.isEmpty()) return null

            val isCellular = NetworkTypeHelper.isOnCellularData(app)
            fun cellularBonus(prof: ProfileItem): Double {
                if (!isCellular) return 0.0
                var bonus = 0.0
                val net = prof.network?.lowercase().orEmpty()
                val sec = prof.security?.lowercase().orEmpty()
                val port = prof.serverPort?.trim().orEmpty()
                if (prof.configType == com.v2ray.ang.enums.EConfigType.VLESS &&
                    (net == "ws" || net == "xhttp" || sec == "reality")
                ) {
                    bonus += 350.0
                } else if (prof.configType == com.v2ray.ang.enums.EConfigType.TROJAN) {
                    bonus += 300.0
                }
                if (port == "443" || port == "8443") {
                    bonus += 180.0
                }
                return bonus
            }

            val ranked = allEntries.sortedByDescending { (_, prof, aff) ->
                val speed = aff?.downloadMbps ?: 0.0
                val delay = (aff?.testDelayMillis ?: 3000L).coerceIn(1L, 5000L)
                val isFresh = aff != null && speed > 0.0 && (now - aff.lastAuditTime) < FRESH_BIDIR_WINDOW_MS
                val isOpen = aff?.countryCode?.uppercase() !in censoredCountries
                val freshBonus = if (isFresh) 5000.0 else 0.0
                val openBonus = if (isOpen && aff?.dnsLeakOk == true) 300.0 else 0.0
                val nativeBonus = if (aff?.isWarp == false) 180.0 else 0.0
                val protoBonus = when (prof.configType) {
                    com.v2ray.ang.enums.EConfigType.VLESS,
                    com.v2ray.ang.enums.EConfigType.TROJAN -> 180.0
                    else -> 0.0
                }
                freshBonus + openBonus + nativeBonus + protoBonus + cellularBonus(prof) + (speed * 1000.0) - (delay * 0.5)
            }

            uiState.value.selectedGuid?.takeIf { it.isNotBlank() }?.let { current ->
                if (ranked.size > 1 && current == ranked.first().first && smartConnectTriedGuids.isEmpty()) {
                    smartConnectTriedGuids.add(current)
                }
            }

            val freshUntried = ranked.firstOrNull { (guid, _, aff) ->
                guid !in smartConnectTriedGuids &&
                    aff != null &&
                    aff.testDelayMillis > 0L &&
                    aff.downloadMbps > 0.0 &&
                    (now - aff.lastAuditTime) < FRESH_BIDIR_WINDOW_MS
            }

            var chosen = freshUntried ?: findLiveBidirectionalCandidate(ranked, smartConnectTriedGuids)
            if (chosen == null && smartConnectTriedGuids.isNotEmpty()) {
                smartConnectTriedGuids.clear()
                chosen = findLiveBidirectionalCandidate(ranked, smartConnectTriedGuids)
            }
            if (chosen == null) {
                return null
            }

            smartConnectTriedGuids.add(chosen.first)
            updateSelectedGuid(chosen.first)
            setupGroupTab(forceRefresh = true)
            val dlTag = chosen.third?.downloadMbps?.takeIf { it > 0.0 }?.let {
                " • ↓" + String.format(java.util.Locale.US, "%.1f", it) + " Mbps"
            }.orEmpty()
            return chosen.first to "⚡ Smart #${smartConnectTriedGuids.size}: ${chosen.second.remarks}$dlTag"
        } finally {
            isLiveProbing.set(false)
        }
    }

    fun updateSelectedGuid(guid: String) {
        dataSource.setSelectServer(guid)
        _uiState.update { it.copy(selectedGuid = guid, selectedServerLabel = resolveSelectedServerLabel(guid)) }
    }

    fun refreshSelectedGuid() {
        val g = dataSource.getSelectServer()
        _uiState.update { it.copy(selectedGuid = g, selectedServerLabel = resolveSelectedServerLabel(g)) }
    }

    fun removeServerAndRefresh(guid: String) {
        if (guid == uiState.value.selectedGuid) {
            toast(R.string.toast_action_not_allowed)
            return
        }
        viewModelScope.launch(ioDispatcher) {
            dataSource.removeServer(guid)
            cacheMutex.withLock { groupDataCache.clear() }
            setupGroupTab(forceRefresh = true).join()
        }
    }

    fun moveServer(groupId: String, fromPosition: Int, toPosition: Int) {
        val groupState = mutableServerGroupState(groupId).value
        val servers = groupState.servers.toMutableList()
        if (!servers.moveItem(fromPosition, toPosition)) return
        val rows = groupState.rows.toMutableList()
        rows.moveItem(fromPosition, toPosition)
        val guids = servers.map { it.guid }
        mutableServerGroupState(groupId).value = ServerGroupUiState(servers, rows)
        // A drag emits several moves; serialize writes so an older order cannot overwrite a newer one.
        val previousPersistenceJob = serverOrderPersistenceJobs[groupId]
        serverOrderPersistenceJobs[groupId] = viewModelScope.launch(ioDispatcher) {
            previousPersistenceJob?.join()
            dataSource.encodeServerList(guids, groupId)
            cacheMutex.withLock { groupDataCache[groupId] = servers }
        }
    }

    // ---------- Testing ----------
    fun cancelAllPing() {
        bulkTestJob?.cancel()
        bulkTestJob = null
        testRequests.cancelBulk()
        testRequests.invalidateCurrent()
        cancelPendingTestResults()
        resetTestStatus()
        dataSource.cancelAllPing()
    }

    private fun resetTestStatus() {
        _uiState.update {
            it.copy(
                isTesting = testRequests.isTesting,
                status = if (testRequests.isTesting) MainStatus.Testing
                else if (it.isRunning) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    fun testAllRealPing(onlyTcp: Boolean = false, strictAudit: Boolean = false) {
        cancelIdleBackgroundAudit()
        cancelAllPing()
        val groupId = uiState.value.selectedGroupId
        val servers = currentServers()
        if (servers.isEmpty()) {
            return
        }
        val serverGuids = servers.map { it.guid }
        mutableServerGroupState(groupId).update { current ->
            current.copy(
                servers = current.servers.map { server ->
                    if (server.testDelayMillis == 0L) server
                    else server.copy(testDelayMillis = 0L)
                },
                rows = current.rows.map { row ->
                    if (row.testDelayMillis == 0L) row
                    else row.copy(testDelayMillis = 0L)
                }
            )
        }
        val request = testRequests.beginBulk(groupId)
        val message = TestServiceMessage(
            key = AppConfig.MSG_MEASURE_CONFIG_START,
            subscriptionId = groupId,
            serverGuids = if (keywordFilter.isNotEmpty() || uiState.value.selectedCountryFilter.isNotEmpty()) serverGuids else emptyList(),
            onlyTcp = onlyTcp,
            strictAudit = strictAudit
        )
        _uiState.update {
            it.copy(
                isTesting = true,
                status = MainStatus.Testing
            )
        }
        val shouldStopVpn = strictAudit && uiState.value.isRunning
        bulkTestJob = viewModelScope.launch {
            if (shouldStopVpn) {
                com.v2ray.ang.handler.MmkvManager.encodeSettings(AppConfig.PREF_KILL_SWITCH_ENABLED, false)
                dataSource.sendMsg2Service(AppConfig.MSG_STATE_STOP, "")
                delay(900)
            }
            withContext(ioDispatcher) {
                dataSource.clearAllTestDelayResults(serverGuids)
                val resetGuids = serverGuids.toHashSet()
                cacheMutex.withLock {
                    groupDataCache[groupId]?.let { cached ->
                        groupDataCache[groupId] = cached.map { server ->
                            if (server.guid !in resetGuids || server.testDelayMillis == 0L) server
                            else server.copy(testDelayMillis = 0L)
                        }
                    }
                }
            }
            dataSource.sendMsg2TestService(message, request.id)
        }
    }

    private fun cancelPendingTestResults() {
        testResultFlushJob?.cancel()
        testResultFlushJob = null
        pendingTestResults.clear()
    }

    fun testCurrentServerRealPing() {
        if (!uiState.value.isRunning) return
        _uiState.update { it.copy(isTesting = true, status = MainStatus.Testing) }
        dataSource.testCurrentServerRealPing("")
    }

    private fun onTestsFinished(requestId: String) {
        if (testRequests.completeBulk(requestId) == null) return
        resetTestStatus()
        viewModelScope.launch(ioDispatcher) {
            cacheMutex.withLock { groupDataCache.clear() }
            reloadAllGroups(_uiState.value.groups.map { it.id })
            refreshSelectedGuid()
        }
    }

    fun triggerLocateSelectedServer() {
        val selected = dataSource.getSelectServer() ?: return
        val profile = dataSource.decodeServerConfig(selected) ?: return
        val groupId = profile.subscriptionId
        if (_uiState.value.groups.none { it.id == groupId }) return
        viewModelScope.launch(ioDispatcher) {
            if (_uiState.value.selectedCountryFilter.isNotEmpty()) {
                _uiState.update { it.copy(selectedCountryFilter = "") }
            }
            updateGroupUi(groupId, loadGroup(groupId))
            if (_uiState.value.selectedGroupId != groupId) {
                dataSource.setSelectedSubscriptionId(groupId)
            }
            val target = LocateTarget(groupId, selected)
            _uiState.update {
                it.copy(selectedGroupId = groupId, locateTarget = target)
            }
        }
    }

    private fun consumeLocateTarget() {
        _uiState.update { it.copy(locateTarget = null) }
    }

    // ---------- Running state ----------
    private fun updateRunningState(running: Boolean, clearTestingText: Boolean = true) {
        if (!running || clearTestingText) testRequests.invalidateCurrent()
        _uiState.update { state ->
            state.copy(
                isRunning = running,
                liveTrafficSpeed = if (running) state.liveTrafficSpeed else "",
                isTesting = testRequests.isTesting,
                status = if (!clearTestingText && state.isRunning == running) state.status
                else if (running) MainStatus.Connected else MainStatus.Disconnected
            )
        }
    }

    override fun onCleared() {
        setupGroupJob?.cancel()
        preloadJob?.cancel()
        selectedGroupLoadJob?.cancel()
        reloadJob?.cancel()
        filterJob?.cancel()
        preScanJob?.cancel()
        cancelAllPing()
        dataSource.close()
        super.onCleared()
    }

    // ---------- Factory ----------
    class Factory(private val application: Application, private val dataSource: MainDataSource) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(application, dataSource) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }

    private companion object {
        const val TEST_RESULT_FLUSH_INTERVAL_MS = 1200L
    }
}
