package com.v2ray.ang.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build

/**
 * Ali baba Smart Network Detector:
 * Automatically detects whether the device is currently on Mobile Cellular Data
 * (e.g., MCI/Irancell/Rightel) vs. Wi-Fi (e.g., MobinNet/ADSL/Fiber) so the app can
 * apply anti-DPI Fragment, optimal MTU (1280), and cellular-friendly Smart Connect
 * scoring without slowing down Wi-Fi connections.
 */
object NetworkTypeHelper {
    @Volatile
    var isCellularActive: Boolean = false
        private set

    fun isOnCellularData(context: Context?): Boolean {
        if (context == null) return isCellularActive
        return try {
            val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val activeNetwork = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
                val hasCellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                val hasWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                val hasEthernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                val result = hasCellular && !hasWifi && !hasEthernet
                isCellularActive = result
                result
            } else {
                @Suppress("DEPRECATION")
                val info = cm.activeNetworkInfo
                @Suppress("DEPRECATION")
                val result = info != null && info.isConnected && info.type == ConnectivityManager.TYPE_MOBILE
                isCellularActive = result
                result
            }
        } catch (_: Exception) {
            isCellularActive
        }
    }

    fun refresh(context: Context?): Boolean {
        return isOnCellularData(context)
    }
}
