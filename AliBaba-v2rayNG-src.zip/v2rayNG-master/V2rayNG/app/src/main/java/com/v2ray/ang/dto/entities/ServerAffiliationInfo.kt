package com.v2ray.ang.dto.entities

import java.io.Serializable

data class ServerAffiliationInfo(
    var testDelayMillis: Long = 0L,
    var countryCode: String? = null,
    var countryName: String? = null,
    var exitIp: String? = null,
    var downloadMbps: Double = 0.0,
    var dnsLeakOk: Boolean = false,
    var geminiOk: Boolean = false,
    var telegramOk: Boolean = false,
    var youtubeOk: Boolean = false,
    var spotifyOk: Boolean = false,
    var strictVerified: Boolean = false,
    var isWarp: Boolean = false,
    var lastAuditTime: Long = 0L,
    var doubleVpnMbps: Double = 0.0,
    var doubleVpnAuditTime: Long = 0L,
) : Serializable
