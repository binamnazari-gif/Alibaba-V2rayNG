package com.v2ray.ang.ui.main

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import com.v2ray.ang.handler.StrictVerificationManager
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.ui.compose.LocalDarkTheme
import com.v2ray.ang.ui.compose.QRCodeDialog
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    mainViewModel: MainViewModel,
    onAction: (MainAction) -> Unit,
    onNavigate: (MainDestination) -> Unit,
) {
    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
    val groups = uiState.groups
    val isLoading by mainViewModel.isLoading.collectAsStateWithLifecycle()
    val isRunning = uiState.isRunning
    val displayText = mainViewModel.formatStatus(uiState.status)
    val selectedGuid = uiState.selectedGuid
    val doubleColumnDisplay = uiState.doubleColumnDisplay
    val confirmRemove = uiState.confirmRemove
    val shareQRCodeBitmap = uiState.shareQRCodeBitmap

    val isDarkTheme = LocalDarkTheme.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showDelAllConfirm by remember { mutableStateOf(false) }
    var showDelDuplicateConfirm by remember { mutableStateOf(false) }
    var showDelInvalidConfirm by remember { mutableStateOf(false) }
    var showAddGroupDialog by remember { mutableStateOf(false) }
    var newGroupName by remember { mutableStateOf("") }
    var deleteGroupTarget by remember { mutableStateOf<com.v2ray.ang.dto.GroupMapItem?>(null) }
    var showRemoveConfirm by rememberSaveable(stateSaver = ServerDeleteTarget.Saver) {
        mutableStateOf<ServerDeleteTarget?>(null)
    }

    var shareTarget by remember { mutableStateOf<Triple<String, ProfileItem, Boolean>?>(null) }
    val removeServer: (String, String) -> Unit = { guid, profileName ->
        if (confirmRemove) {
            showRemoveConfirm = ServerDeleteTarget(guid, profileName)
        } else {
            onAction(MainAction.RemoveServer(guid))
        }
    }

    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { groups.size.coerceAtLeast(1) }
    )

    val lazyListStates = remember { mutableStateMapOf<String, LazyListState>() }
    val lazyGridStates = remember { mutableStateMapOf<String, LazyGridState>() }

    LaunchedEffect(groups) {
        val validGroupIds = groups.map { it.id }.toSet()
        lazyListStates.keys.retainAll(validGroupIds)
        lazyGridStates.keys.retainAll(validGroupIds)
    }

    LaunchedEffect(groups, uiState.selectedGroupId) {
        if (groups.isEmpty()) return@LaunchedEffect
        val selectedIndex = groups.indexOfFirst { it.id == uiState.selectedGroupId }
            .takeIf { it >= 0 } ?: 0
        if (!pagerState.isScrollInProgress && pagerState.settledPage != selectedIndex) {
            pagerState.scrollToPage(selectedIndex)
        }
    }

    val latestGroups by rememberUpdatedState(groups)
    // Height of the floating connection bar, so the server lists can scroll clear of it.
    var bottomBarHeightPx by remember { mutableIntStateOf(0) }

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }
            .distinctUntilChanged()
            .collect { page ->
                val currentGroups = latestGroups
                if (page in currentGroups.indices) {
                    onAction(MainAction.SelectGroup(currentGroups[page].id))
                }
            }
    }

    MainDialogs(
        showDelAllConfirm = showDelAllConfirm,
        onDismissDelAll = { showDelAllConfirm = false },
        onConfirmDelAll = { showDelAllConfirm = false; onAction(MainAction.RemoveAllServers) },
        showDelDuplicateConfirm = showDelDuplicateConfirm,
        onDismissDelDuplicate = { showDelDuplicateConfirm = false },
        onConfirmDelDuplicate = { showDelDuplicateConfirm = false; onAction(MainAction.RemoveDuplicateServers) },
        showDelInvalidConfirm = showDelInvalidConfirm,
        onDismissDelInvalid = { showDelInvalidConfirm = false },
        onConfirmDelInvalid = { showDelInvalidConfirm = false; onAction(MainAction.RemoveInvalidServers) },
        showRemoveConfirm = showRemoveConfirm,
        onDismissRemove = { showRemoveConfirm = null },
        onConfirmRemove = { guid -> showRemoveConfirm = null; onAction(MainAction.RemoveServer(guid)) }
    )

    if (showAddGroupDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showAddGroupDialog = false },
            title = { Text("New Tab / تب جدید") },
            text = {
                androidx.compose.material3.OutlinedTextField(
                    value = newGroupName,
                    onValueChange = { newGroupName = it },
                    singleLine = true,
                    placeholder = { Text("Tab name...") }
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        val name = newGroupName.trim()
                        if (name.isNotEmpty()) {
                            onAction(MainAction.CreateGroup(name))
                        }
                        newGroupName = ""
                        showAddGroupDialog = false
                    }
                ) {
                    Text(androidx.compose.ui.res.stringResource(R.string.action_ok))
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { showAddGroupDialog = false; newGroupName = "" }
                ) {
                    Text(androidx.compose.ui.res.stringResource(R.string.action_cancel))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
    deleteGroupTarget?.let { target ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { deleteGroupTarget = null },
            title = { Text("Delete '${target.remarks}'?") },
            text = { Text("This will delete the tab '${target.remarks}' and all configs inside it.") },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        onAction(MainAction.DeleteGroup(target.id))
                        deleteGroupTarget = null
                    }
                ) {
                    Text(androidx.compose.ui.res.stringResource(R.string.action_ok), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { deleteGroupTarget = null }) {
                    Text(androidx.compose.ui.res.stringResource(R.string.action_cancel))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (shareTarget != null) {
        val (guid, profile, more) = shareTarget!!
        ShareMethodDialog(
            guid = guid,
            profile = profile,
            more = more,
            onDismiss = { shareTarget = null },
            onAction = onAction,
            onRemove = removeServer,
        )
    }
    if (shareQRCodeBitmap != null) {
        QRCodeDialog(bitmap = shareQRCodeBitmap, onDismiss = { onAction(MainAction.DismissQRCodeDialog) })
    }
    val availableUpdate = uiState.availableUpdate
    if (availableUpdate != null && availableUpdate.hasUpdate) {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { onAction(MainAction.DismissUpdateDialog) },
            title = {
                Text(
                    androidx.compose.ui.res.stringResource(
                        R.string.update_new_version_found,
                        availableUpdate.latestVersion ?: ""
                    )
                )
            },
            text = {
                Text(
                    availableUpdate.releaseNotes?.takeIf { it.isNotBlank() }
                        ?: "A new version of Ali baba is available."
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        onAction(MainAction.DismissUpdateDialog)
                        availableUpdate.downloadUrl?.let { com.v2ray.ang.util.Utils.openUri(ctx, it) }
                    }
                ) {
                    Text(androidx.compose.ui.res.stringResource(R.string.update_now))
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { onAction(MainAction.DismissUpdateDialog) }
                ) {
                    Text(androidx.compose.ui.res.stringResource(R.string.action_cancel))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            MainDrawerContent(
                drawerState = drawerState,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    onNavigate(route)
                }
            )
        }
    ) {
        Scaffold(
            contentWindowInsets = ScaffoldDefaults.contentWindowInsets,
            topBar = {
                MainTopBar(
                    isLoading = isLoading,
                    showSearch = showSearch,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { query: String ->
                        searchQuery = query
                        onAction(MainAction.Search(query))
                    },
                    onSearchClose = {
                        searchQuery = ""
                        onAction(MainAction.Search(""))
                        showSearch = false
                    },
                    onSearchToggle = { show: Boolean -> showSearch = show },
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onAction = onAction,
                    onMoreMenuAction = { action ->
                        when (action) {
                            MainMoreMenuAction.RestartService -> onAction(MainAction.RestartService)
                            MainMoreMenuAction.DeleteAll -> showDelAllConfirm = true
                            MainMoreMenuAction.DeleteDuplicate -> showDelDuplicateConfirm = true
                            MainMoreMenuAction.DeleteInvalid -> showDelInvalidConfirm = true
                            MainMoreMenuAction.ExportAll -> onAction(MainAction.ExportAll)
                            MainMoreMenuAction.LocateSelected -> onAction(MainAction.LocateSelectedServer)
                            MainMoreMenuAction.SortByTestResults -> onAction(MainAction.SortByTestResults)
                            MainMoreMenuAction.TestAll -> onAction(MainAction.TestAllServers)
                            MainMoreMenuAction.StrictAuditAll -> onAction(MainAction.StrictAuditAllServers)
                            MainMoreMenuAction.SortByStrictScore -> onAction(MainAction.SortByStrictScore)
                            MainMoreMenuAction.TestAllRealPing -> onAction(MainAction.TestRealAllServers)
                            MainMoreMenuAction.UpdateSubscriptions -> onAction(MainAction.UpdateSubscriptions)
                        }
                    }
                )
            },
            floatingActionButton = {},
        ) { innerPadding ->
            val layoutDirection = LocalLayoutDirection.current
            val bottomBarHeight = with(LocalDensity.current) { bottomBarHeightPx.toDp() }

            Box(Modifier.fillMaxSize()) {
            if (groups.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        // No bottom padding: the lists run behind the floating connection bar.
                        .padding(
                            start = innerPadding.calculateStartPadding(layoutDirection),
                            top = innerPadding.calculateTopPadding(),
                            end = innerPadding.calculateEndPadding(layoutDirection)
                        )
                ) {
                    GroupTabBar(
                        groups = groups,
                        selectedTabIndex = pagerState.currentPage.coerceIn(0, groups.lastIndex),
                        mainViewModel = mainViewModel,
                        onTabClick = { targetIndex ->
                            scope.launch {
                                pagerState.navigateToPageOptimized(
                                    targetPage = targetIndex,
                                    animateAdjacentPage = true
                                )
                            }
                        },
                        onAddGroupClick = { showAddGroupDialog = true },
                        onLongClickGroup = { group ->
                            if (group.id.isNotEmpty()) {
                                deleteGroupTarget = group
                            }
                        }
                    )

                    val currentGroupStateFlow = remember(uiState.selectedGroupId) {
                        mainViewModel.serverGroupState(uiState.selectedGroupId)
                    }
                    val currentGroupState by currentGroupStateFlow.collectAsStateWithLifecycle()
                    val filterScrollState = rememberScrollState()
                    val colors = MaterialTheme.colorScheme

                    val isTestingNow = uiState.isTesting
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                if (isTestingNow) onAction(MainAction.CancelTesting)
                                else onAction(MainAction.StrictAuditAllServers)
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isTestingNow) colors.surfaceContainerHigh else colors.primaryContainer.copy(alpha = 0.85f),
                        border = BorderStroke(
                            1.dp,
                            if (isTestingNow) colors.primary.copy(alpha = 0.7f) else colors.primary
                        ),
                        shadowElevation = 2.dp
                    ) {
                        AnimatedContent(targetState = isTestingNow, label = "audit_btn_anim") { testing ->
                            if (testing) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        NeuralThinkingOrb(
                                            primaryColor = colors.primary,
                                            accentColor = colors.tertiary,
                                            modifier = Modifier.size(30.dp)
                                        )
                                        Column {
                                            Text(
                                                text = displayText,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = colors.onSurface
                                            )
                                            Text(
                                                text = "Gemini • DNS Leak • Speed",
                                                fontSize = 11.sp,
                                                color = colors.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = colors.errorContainer
                                    ) {
                                        Text(
                                            text = androidx.compose.ui.res.stringResource(R.string.action_cancel),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = colors.onErrorContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "⚡ Strict Audit (${currentGroupState.servers.size})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.onPrimaryContainer,
                                        maxLines = 1
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = colors.primary
                                    ) {
                                        Text(
                                            text = "Start",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.onPrimary,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(filterScrollState)
                            .padding(horizontal = 12.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        val isAllSelected = uiState.selectedCountryFilter.isEmpty()
                        Surface(
                            modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onAction(MainAction.SelectCountryFilter("")) },
                            shape = RoundedCornerShape(50),
                            color = if (isAllSelected) colors.secondaryContainer else colors.surfaceContainerHigh,
                            border = BorderStroke(1.dp, if (isAllSelected) colors.secondary else colors.outlineVariant)
                        ) {
                            Text(
                                text = androidx.compose.ui.res.stringResource(R.string.filter_all_servers),
                                fontSize = 12.sp,
                                color = if (isAllSelected) colors.onSecondaryContainer else colors.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                            )
                        }

                        val isGeminiSelected = uiState.selectedCountryFilter == "__GEMINI_OK__"
                        Surface(
                            modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onAction(MainAction.SelectCountryFilter("__GEMINI_OK__")) },
                            shape = RoundedCornerShape(50),
                            color = if (isGeminiSelected) colors.tertiaryContainer else colors.surfaceContainerHigh,
                            border = BorderStroke(1.dp, if (isGeminiSelected) colors.tertiary else colors.outlineVariant)
                        ) {
                            Text(
                                text = "✅ " + androidx.compose.ui.res.stringResource(R.string.filter_gemini_verified) + " (${currentGroupState.verifiedCount})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isGeminiSelected) colors.onTertiaryContainer else colors.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                            )
                        }

                        currentGroupState.availableCountries.forEach { (code, count) ->
                            val isSelected = uiState.selectedCountryFilter.equals(code, ignoreCase = true)
                            Surface(
                                modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onAction(MainAction.SelectCountryFilter(code)) },
                                shape = RoundedCornerShape(50),
                                color = if (isSelected) colors.primaryContainer else colors.surfaceContainerHigh,
                                border = BorderStroke(1.dp, if (isSelected) colors.primary else colors.outlineVariant)
                            ) {
                                Text(
                                    text = "${StrictVerificationManager.countryFlag(code)} $code ($count)",
                                    fontSize = 12.sp,
                                    color = if (isSelected) colors.onPrimaryContainer else colors.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    if (uiState.selectedServerLabel.isNotBlank()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onAction(MainAction.LocateSelectedServer) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isRunning) colors.tertiaryContainer.copy(alpha = 0.55f) else colors.surfaceContainerHigh,
                            border = BorderStroke(
                                1.dp,
                                if (isRunning) colors.tertiary.copy(alpha = 0.7f) else colors.outlineVariant
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = (if (isRunning) "● " else "○ ") + uiState.selectedServerLabel,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isRunning) colors.onTertiaryContainer else colors.onSurface,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Locate ↗",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isRunning) colors.tertiary else colors.primary
                                )
                            }
                        }
                    }

                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        userScrollEnabled = true,
                        beyondViewportPageCount = 1,
                        key = { page -> groups.getOrNull(page)?.id ?: "group-page-$page" }
                    ) { page ->
                        val group = groups.getOrNull(page) ?: return@HorizontalPager

                        GroupPagerPage(
                            groupId = group.id,
                            mainViewModel = mainViewModel,
                            selectedGuid = selectedGuid,
                            liveTrafficSpeed = if (isRunning) uiState.liveTrafficSpeed.ifBlank { "DL 0 B/s • UL 0 B/s" } else "",
                            locateTarget = uiState.locateTarget,
                            doubleColumnDisplay = doubleColumnDisplay,
                            searchQuery = searchQuery,
                            lazyListStates = lazyListStates,
                            lazyGridStates = lazyGridStates,
                            onSelectServer = { guid -> onAction(MainAction.SelectServer(guid)) },
                            onEditServer = { guid, profile -> onAction(MainAction.EditServer(guid, profile)) },
                            onShareServer = { guid, profile ->
                                shareTarget = Triple(guid, profile, false)
                            },
                            onMoreServer = { guid, profile ->
                                shareTarget = Triple(guid, profile, true)
                            },
                            onRemoveServer = removeServer,
                            usageInfo = group.usageInfo,
                            groupTitle = group.remarks,
                            onOpenLink = { url -> onAction(MainAction.OpenSubscriptionLink(url)) },
                            contentPadding = PaddingValues(
                                start = 0.dp,
                                top = 0.dp,
                                end = 0.dp,
                                bottom = bottomBarHeight + 8.dp
                            )
                        )
                    }
                }
            }
            MainBottomBar(
                displayText = displayText,
                isRunning = isRunning,
                isDarkTheme = isDarkTheme,
                onAction = onAction,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { bottomBarHeightPx = it.height }
            )
            }
        }
    }
}


@Composable
private fun NeuralThinkingOrb(
    primaryColor: Color,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "neural_orb")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_phase"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.38f
        val nodeCount = 10
        val points = ArrayList<Triple<Float, Float, Float>>(nodeCount)

        for (i in 0 until nodeCount) {
            val lat = (i.toFloat() / nodeCount) * PI.toFloat() - (PI.toFloat() / 2f)
            val lon = phase * (if (i % 2 == 0) 1f else -0.8f) + i * 1.15f
            val x = cos(lat) * cos(lon)
            val y = sin(lat) * 0.85f + 0.15f * sin(phase + i)
            val z = cos(lat) * sin(lon) // depth in [-1, 1]
            points.add(Triple(cx + x * r, cy + y * r, z))
        }

        // Draw subtle neural links between nearby nodes
        for (i in 0 until nodeCount) {
            for (j in i + 1 until nodeCount) {
                val p1 = points[i]
                val p2 = points[j]
                val dx = p1.first - p2.first
                val dy = p1.second - p2.second
                val distSq = dx * dx + dy * dy
                val maxDistSq = (r * 1.25f) * (r * 1.25f)
                if (distSq < maxDistSq) {
                    val alpha = (1f - distSq / maxDistSq) * 0.35f
                    drawLine(
                        color = primaryColor.copy(alpha = alpha.coerceIn(0.05f, 0.4f)),
                        start = Offset(p1.first, p1.second),
                        end = Offset(p2.first, p2.second),
                        strokeWidth = 1.2f
                    )
                }
            }
        }

        // Draw orbiting glowing nodes with depth sizing & alpha
        points.forEachIndexed { idx, (px, py, pz) ->
            val depth = ((pz + 1f) / 2f).coerceIn(0f, 1f)
            val dotRadius = 1.6f + depth * 2.4f
            val dotAlpha = 0.25f + depth * 0.75f
            val color = if (idx % 3 == 0) accentColor else primaryColor
            drawCircle(
                color = color.copy(alpha = dotAlpha),
                radius = dotRadius,
                center = Offset(px, py)
            )
        }
    }
}
