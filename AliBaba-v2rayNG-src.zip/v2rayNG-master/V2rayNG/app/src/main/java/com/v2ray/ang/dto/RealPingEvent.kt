package com.v2ray.ang.dto

import com.v2ray.ang.dto.entities.ServerAffiliationInfo

sealed class RealPingEvent {

    /** Periodic progress update while the batch is still running. */
    data class Progress(val text: String) : RealPingEvent()

    /** A single server result is available. */
    data class Result(
        val guid: String,
        val delayMillis: Long,
        val affiliationInfo: ServerAffiliationInfo? = null,
    ) : RealPingEvent()

    /** The entire batch has finished or been cancelled. */
    data class Finish(val status: String) : RealPingEvent()
}
