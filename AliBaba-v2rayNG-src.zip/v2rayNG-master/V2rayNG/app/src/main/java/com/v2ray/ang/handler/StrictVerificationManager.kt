package com.v2ray.ang.handler

import android.content.Context
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.CoreConfigManager
import com.v2ray.ang.core.CoreNativeManager
import com.v2ray.ang.dto.IPAPIInfo
import com.v2ray.ang.dto.entities.ServerAffiliationInfo
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.isNotNullEmpty
import com.v2ray.ang.util.JsonUtil
import com.v2ray.ang.util.LogUtil
import libv2ray.CoreCallbackHandler
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.util.Locale
import java.util.concurrent.TimeUnit

object StrictVerificationManager {

    private val GEMINI_BLOCKED_COUNTRIES = setOf("IR", "CN", "RU", "HK", "MO", "BY", "KP", "CU", "SY")
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private class SilentCoreCallback : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(l: Long, s: String?): Long = 0
    }

    fun auditServer(context: Context, guid: String): ServerAffiliationInfo {
        val now = System.currentTimeMillis()
        val config = MmkvManager.decodeServerConfig(guid)
            ?: return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)

        // Fast TCP pre-check (2.2s timeout); keep tcpTime so live servers aren't marked dead in All tab
        var fallbackTcpTime = -1L
        if (!config.configType.isComplexType()
            && config.configType != EConfigType.HYSTERIA2
            && config.configType != EConfigType.WIREGUARD
            && config.alpn?.startsWith("h3") != true
            && config.server.isNotNullEmpty()
            && config.serverPort?.toIntOrNull() != null
        ) {
            fallbackTcpTime = SpeedtestManager.socketConnectTime(
                config.server.orEmpty(),
                config.serverPort.orEmpty().toInt(),
                1500
            )
            if (fallbackTcpTime <= -1L) {
                return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
            }
        }

        val configResult = CoreConfigManager.getV2rayConfig4Speedtest(context, guid)
        if (!configResult.status || configResult.content.isBlank()) {
            return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        }

        val httpProxyPort = allocateFreePort()
        if (httpProxyPort <= 0) {
            return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        }

        // CRITICAL FIX: Use HTTP CONNECT inbound instead of SOCKS5!
        // With Proxy.Type.HTTP, OkHttp sends raw hostnames (CONNECT host:443) directly into Xray
        // instead of resolving DNS locally on the phone (which gets poisoned to 10.10.34.x in Iran).
        val patchedConfig = injectAuditHttpInbound(configResult.content, httpProxyPort)
            ?: return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)

        val controller = CoreNativeManager.newCoreController(SilentCoreCallback())
        return try {
            controller.startLoop(patchedConfig, 0)
            Thread.sleep(220)

            val client = OkHttpClient.Builder()
                .proxy(Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", httpProxyPort)))
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(6, TimeUnit.SECONDS)
                .writeTimeout(5, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            // 1. Latency check with 1 retry so live servers aren't lost to a cold-start blip
            var delayMs = measureHttpLatency(client, AppConfig.DELAY_TEST_URL)
            if (delayMs < 0L) {
                Thread.sleep(250)
                delayMs = measureHttpLatency(client, AppConfig.DELAY_TEST_URL)
            }
            if (delayMs < 0L) {
                return ServerAffiliationInfo(testDelayMillis = fallbackTcpTime, lastAuditTime = now)
            }

            // 2. Fast Exit IP, Country & DNS Leak check (single CF Trace, fallback only if needed)
            val cfTrace = fetchCloudflareTrace(client, "https://cloudflare.com/cdn-cgi/trace")
            val cfDnsTrace = if (cfTrace["loc"].isNullOrBlank()) {
                fetchCloudflareTrace(client, "https://1.1.1.1/cdn-cgi/trace")
            } else emptyMap()
            val geoInfo = if (cfTrace["loc"].isNullOrBlank() && cfDnsTrace["loc"].isNullOrBlank()) {
                fetchGeoIp(client)
            } else null

            val rawCode = listOfNotNull(
                cfTrace["loc"],
                cfDnsTrace["loc"],
                geoInfo?.country_code,
                geoInfo?.countryCode,
                geoInfo?.location?.country_code
            ).firstOrNull { it.isNotBlank() && it.length == 2 }?.uppercase(Locale.US)

            val exitIp = listOfNotNull(
                cfTrace["ip"],
                cfDnsTrace["ip"],
                geoInfo?.ip,
                geoInfo?.clientIp,
                geoInfo?.ip_addr,
                geoInfo?.query
            ).firstOrNull { it.isNotBlank() }

            val isWarp = exitIp != null && (
                exitIp.startsWith("104.28.") ||
                    exitIp.startsWith("104.29.") ||
                    exitIp.startsWith("172.71.")
                )

            val countryName = geoInfo?.country_name?.takeIf { it.isNotBlank() }
                ?: geoInfo?.country?.takeIf { it.isNotBlank() }
                ?: countryDisplayName(rawCode)

            val cfLoc = cfTrace["loc"]?.uppercase(Locale.US)
            val cfDnsLoc = cfDnsTrace["loc"]?.uppercase(Locale.US)
            val dnsLeakOk = rawCode != null &&
                rawCode != "IR" &&
                (cfLoc == null || cfLoc != "IR") &&
                (cfDnsLoc == null || cfDnsLoc != "IR") &&
                !exitIp.isNullOrBlank()

            // 3. Balanced Download Speed test (256 KB via Cloudflare CDN)
            val downloadMbps = measureDownloadSpeedMbps(client)

            // 4. Strict Service Check (Google-level GeoIP + Gemini)
            val geminiOk = checkGemini(client, rawCode)

            val strictVerified = delayMs > 0L &&
                downloadMbps >= 0.15 &&
                dnsLeakOk &&
                geminiOk &&
                rawCode != null &&
                rawCode !in GEMINI_BLOCKED_COUNTRIES

            ServerAffiliationInfo(
                testDelayMillis = delayMs,
                countryCode = rawCode,
                countryName = countryName,
                exitIp = exitIp,
                downloadMbps = downloadMbps,
                dnsLeakOk = dnsLeakOk,
                geminiOk = geminiOk,
                strictVerified = strictVerified,
                isWarp = isWarp,
                lastAuditTime = now
            )
        } catch (e: Throwable) {
            LogUtil.e(AppConfig.TAG, "Strict audit failed for $guid", e)
            ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        } finally {
            runCatching {
                if (controller.isRunning) {
                    controller.stopLoop()
                }
            }
        }
    }

    private fun allocateFreePort(): Int = try {
        ServerSocket(0).use { it.localPort }
    } catch (_: Exception) {
        -1
    }

    private fun injectAuditHttpInbound(rawJson: String, port: Int): String? {
        return try {
            val root = JsonParser.parseString(rawJson).asJsonObject
            val httpInbound = JsonObject().apply {
                addProperty("tag", "audit-http")
                addProperty("listen", "127.0.0.1")
                addProperty("port", port)
                addProperty("protocol", "http")
                add("settings", JsonObject().apply {
                    addProperty("allowTransparent", false)
                })
                add("sniffing", JsonObject().apply {
                    addProperty("enabled", true)
                    add("destOverride", JsonArray().apply {
                        add("http")
                        add("tls")
                        add("quic")
                    })
                })
            }
            root.add("inbounds", JsonArray().apply { add(httpInbound) })
            root.add("dns", JsonObject().apply {
                add("servers", JsonArray().apply {
                    add("1.1.1.1")
                    add("8.8.8.8")
                })
            })
            root.toString()
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Failed to patch audit config", e)
            null
        }
    }

    private fun measureHttpLatency(client: OkHttpClient, url: String): Long {
        return try {
            val start = System.currentTimeMillis()
            val req = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (resp.code in 200..399) {
                    (System.currentTimeMillis() - start).coerceAtLeast(1L)
                } else {
                    -1L
                }
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun fetchCloudflareTrace(client: OkHttpClient, url: String): Map<String, String> {
        return try {
            val req = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyMap()
                val body = resp.body?.string().orEmpty()
                body.lineSequence()
                    .mapNotNull { line ->
                        val idx = line.indexOf('=')
                        if (idx > 0) line.substring(0, idx).trim() to line.substring(idx + 1).trim()
                        else null
                    }
                    .toMap()
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun fetchGeoIp(client: OkHttpClient): IPAPIInfo? {
        return try {
            val req = Request.Builder().url(AppConfig.IP_API_URL).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty()
                JsonUtil.fromJsonSafe(body, IPAPIInfo::class.java)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun measureDownloadSpeedMbps(client: OkHttpClient): Double {
        return try {
            val req = Request.Builder()
                .url("https://speed.cloudflare.com/__down?bytes=131072")
                .header("User-Agent", USER_AGENT)
                .build()
            val start = System.currentTimeMillis()
            var totalBytes = 0L
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return 0.0
                val stream = resp.body?.byteStream() ?: return 0.0
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val read = stream.read(buf)
                    if (read == -1) break
                    totalBytes += read
                }
            }
            val elapsedMs = (System.currentTimeMillis() - start).coerceAtLeast(1L)
            if (totalBytes <= 0L) 0.0 else (totalBytes * 8.0) / (elapsedMs * 1000.0)
        } catch (_: Exception) {
            0.0
        }
    }

    private fun checkGemini(client: OkHttpClient, countryCode: String?): Boolean {
        if (countryCode != null && countryCode in GEMINI_BLOCKED_COUNTRIES) return false

        // Step A: Check Google's OWN GeoIP classification of this IP.
        // Public US proxies used heavily from Iran get re-geolocated to "IR" by Google even when Cloudflare says "US".
        val googleGeoOk = try {
            val gReq = Request.Builder()
                .url("https://www.google.com/?hl=en")
                .header("User-Agent", USER_AGENT)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            client.newCall(gReq).execute().use { resp ->
                val finalUrl = resp.request.url.toString().lowercase(Locale.US)
                if (finalUrl.contains("/sorry") || resp.code == 429) return false
                val body = resp.body?.string().orEmpty()
                val lower = body.lowercase(Locale.US)
                // Google embeds country in footer/JSON when IP is mapped to Iran
                val mappedToBlocked = lower.contains(">iran<") ||
                    lower.contains(">russia<") ||
                    lower.contains(">hong kong<") ||
                    lower.contains("\"ir\",\"iran\"") ||
                    lower.contains("uule_country\":\"ir\"") ||
                    body.contains("ایران")
                !mappedToBlocked
            }
        } catch (_: Exception) {
            true
        }
        if (!googleGeoOk) return false

        // Step B: Direct Gemini page check (detects both plain and JS/HTML-escaped unsupported messages)
        return try {
            val req = Request.Builder()
                .url("https://gemini.google.com/app?hl=en")
                .header("User-Agent", USER_AGENT)
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()
            client.newCall(req).execute().use { resp ->
                val finalUrl = resp.request.url.toString().lowercase(Locale.US)
                if (resp.code == 403 || resp.code == 429 || resp.code >= 500) return false
                if (finalUrl.contains("unsupported") || finalUrl.contains("/sorry")) return false
                val rawBody = resp.body?.string().orEmpty()
                val body = rawBody.lowercase(Locale.US)
                if (body.contains("stay tuned") ||
                    body.contains("currently supported") ||
                    body.contains("not available in your country") ||
                    body.contains("detected unusual traffic") ||
                    body.contains("country_not_supported") ||
                    body.contains("unsupported_country") ||
                    rawBody.contains("در کشورتان پشتیبانی نمی‌شود") ||
                    rawBody.contains("پشتیبانی نمی‌شود")
                ) {
                    return false
                }
                resp.code in 200..399 && rawBody.length > 2000 &&
                    (body.contains("gemini") || body.contains("accounts.google.com"))
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun checkTelegram(client: OkHttpClient): Boolean {
        return try {
            val apiReq = Request.Builder()
                .url("https://api.telegram.org/")
                .header("User-Agent", USER_AGENT)
                .build()
            val apiOk = client.newCall(apiReq).execute().use { resp ->
                resp.code in 200..499
            }
            if (!apiOk) return false
            val webReq = Request.Builder()
                .url("https://t.me/")
                .header("User-Agent", USER_AGENT)
                .build()
            client.newCall(webReq).execute().use { resp ->
                resp.code in 200..399
            }
        } catch (_: Exception) {
            false
        }
    }


    private val KNOWN_COUNTRY_KEYWORDS = listOf(
        "UNITED STATES" to "US", "USA" to "US", "AMERICA" to "US",
        "GERMANY" to "DE", "FRANKFURT" to "DE",
        "NETHERLANDS" to "NL", "AMSTERDAM" to "NL",
        "FRANCE" to "FR", "PARIS" to "FR",
        "TURKEY" to "TR", "ISTANBUL" to "TR",
        "FINLAND" to "FI", "HELSINKI" to "FI",
        "UNITED KINGDOM" to "GB", "LONDON" to "GB", "UK" to "GB",
        "CANADA" to "CA", "TORONTO" to "CA",
        "POLAND" to "PL", "WARSAW" to "PL",
        "SWEDEN" to "SE", "STOCKHOLM" to "SE",
        "SWITZERLAND" to "CH", "ZURICH" to "CH",
        "JAPAN" to "JP", "TOKYO" to "JP",
        "SINGAPORE" to "SG",
        "AUSTRALIA" to "AU", "SYDNEY" to "AU",
        "UKRAINE" to "UA",
        "ESTONIA" to "EE",
        "BULGARIA" to "BG",
        "MEXICO" to "MX",
        "UAE" to "AE", "DUBAI" to "AE",
        "AUSTRIA" to "AT", "VIENNA" to "AT",
        "ITALY" to "IT", "MILAN" to "IT",
        "SPAIN" to "ES", "MADRID" to "ES",
        "RUSSIA" to "RU", "MOSCOW" to "RU",
        "INDIA" to "IN", "BRAZIL" to "BR", "KOREA" to "KR",
        "NORWAY" to "NO", "DENMARK" to "DK", "IRELAND" to "IE",
        "CZECH" to "CZ", "ROMANIA" to "RO", "HUNGARY" to "HU"
    )

    private val BRACKET_CODE_REGEX = Regex("(?:\\[|\\(|^|\\s|-)([A-Z]{2})(?:\\]|\\)|\\s|-|\\d|$)")
    private val VALID_ISO_CODES = Locale.getISOCountries().toSet()

    fun guessCountryCodeFromRemarks(remarks: String?): String? {
        if (remarks.isNullOrBlank()) return null
        // 1. Check Regional Indicator Flag Emojis (e.g. 🇺🇸 -> US)
        var i = 0
        while (i < remarks.length) {
            val cp1 = remarks.codePointAt(i)
            val len1 = Character.charCount(cp1)
            if (cp1 in 0x1F1E6..0x1F1FF && i + len1 < remarks.length) {
                val cp2 = remarks.codePointAt(i + len1)
                if (cp2 in 0x1F1E6..0x1F1FF) {
                    val c1 = ('A'.code + (cp1 - 0x1F1E6)).toChar()
                    val c2 = ('A'.code + (cp2 - 0x1F1E6)).toChar()
                    val code = "$c1$c2"
                    if (code in VALID_ISO_CODES && code != "IR") return code
                }
            }
            i += len1
        }
        // 2. Check explicit country/city names
        val upper = remarks.uppercase(Locale.US)
        for ((kw, code) in KNOWN_COUNTRY_KEYWORDS) {
            if (upper.contains(kw)) return code
        }
        // 3. Check 2-letter ISO code tokens like [US], DE-01, TR DIRECT
        BRACKET_CODE_REGEX.findAll(upper).forEach { m ->
            val code = m.groupValues[1]
            if (code in VALID_ISO_CODES && code != "IR" && code != "ID" && code != "IN" && code != "IS" && code != "IT" && code != "AT" && code != "TO" && code != "ME" && code != "BY" && code != "NO" && code != "DO" && code != "SO" && code != "AM" && code != "PM" && code != "TV" && code != "WS") {
                return code
            }
        }
        return null
    }

    fun countryFlag(countryCode: String?): String {
        val code = countryCode?.trim()?.uppercase(Locale.US) ?: return "🌐"
        if (code.length != 2 || code.any { it !in 'A'..'Z' }) return "🌐"
        val first = Character.codePointAt(code, 0) - 0x41 + 0x1F1E6
        val second = Character.codePointAt(code, 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(first)) + String(Character.toChars(second))
    }

    fun countryDisplayName(countryCode: String?): String {
        val code = countryCode?.trim()?.uppercase(Locale.US) ?: return "Unknown"
        return Locale("", code).getDisplayCountry(Locale.ENGLISH).ifBlank { code }
    }
}
