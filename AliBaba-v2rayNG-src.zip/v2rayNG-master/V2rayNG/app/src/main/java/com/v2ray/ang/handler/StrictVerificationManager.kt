package com.v2ray.ang.handler

import android.content.Context
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.CoreConfigManager
import com.v2ray.ang.core.CoreNativeManager
import com.v2ray.ang.dto.IPAPIInfo
import com.v2ray.ang.dto.entities.ServerAffiliationInfo
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.isNotNullEmpty
import com.v2ray.ang.util.JsonUtil
import com.v2ray.ang.util.LogUtil
import libv2ray.CoreCallbackHandler
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.util.Locale
import java.util.concurrent.TimeUnit

object StrictVerificationManager {

    private val GEMINI_BLOCKED_COUNTRIES = setOf("IR", "CN", "RU", "HK", "MO", "BY", "KP", "CU", "SY")
    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private class SilentCoreCallback : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(l: Long, s: String?): Long = 0
    }

    fun auditServer(context: Context, guid: String): ServerAffiliationInfo {
        val now = System.currentTimeMillis()
        val config = MmkvManager.decodeServerConfig(guid)
            ?: return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)

        // Fast TCP pre-check for standard protocols
        if (!config.configType.isComplexType()
            && config.configType != EConfigType.HYSTERIA2
            && config.configType != EConfigType.WIREGUARD
            && config.alpn?.startsWith("h3") != true
            && config.server.isNotNullEmpty()
            && config.serverPort?.toIntOrNull() != null
        ) {
            val tcpTime = SpeedtestManager.socketConnectTime(
                config.server.orEmpty(),
                config.serverPort.orEmpty().toInt(),
                1500
            )
            if (tcpTime <= -1L) {
                return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
            }
        }

        val configResult = CoreConfigManager.getV2rayConfig4Speedtest(context, guid)
        if (!configResult.status || configResult.content.isBlank()) {
            return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        }

        val socksPort = allocateFreePort()
        if (socksPort <= 0) {
            return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        }

        val patchedConfig = injectAuditSocksAndDns(configResult.content, socksPort)
            ?: return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)

        val controller = CoreNativeManager.newCoreController(SilentCoreCallback())
        return try {
            controller.startLoop(patchedConfig, 0)
            Thread.sleep(200)

            val client = OkHttpClient.Builder()
                .proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", socksPort)))
                .connectTimeout(7, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(7, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            // 1. Latency check (gstatic generate_204)
            val delayMs = measureHttpLatency(client, AppConfig.DELAY_TEST_URL)
            if (delayMs < 0L) {
                return ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
            }

            // 2. Exit IP, Country & DNS Leak check (Cloudflare Trace primary + optional GeoIP)
            val cfTrace = fetchCloudflareTrace(client, "https://cloudflare.com/cdn-cgi/trace")
            val cfDnsTrace = fetchCloudflareTrace(client, "https://1.1.1.1/cdn-cgi/trace")
            val geoInfo = fetchGeoIp(client)

            val rawCode = listOfNotNull(
                cfTrace["loc"],
                cfDnsTrace["loc"],
                geoInfo?.country_code,
                geoInfo?.countryCode,
                geoInfo?.location?.country_code
            ).firstOrNull { it.isNotBlank() && it.length == 2 }?.uppercase(Locale.US)

            val exitIp = listOfNotNull(
                cfTrace["ip"],
                geoInfo?.ip,
                geoInfo?.clientIp,
                geoInfo?.ip_addr,
                geoInfo?.query
            ).firstOrNull { it.isNotBlank() }

            val isWarp = exitIp != null && (
                exitIp.startsWith("104.28.") ||
                    exitIp.startsWith("104.29.") ||
                    exitIp.startsWith("172.71.")
                )

            val countryName = geoInfo?.country_name?.takeIf { it.isNotBlank() }
                ?: geoInfo?.country?.takeIf { it.isNotBlank() }
                ?: countryDisplayName(rawCode)

            val cfLoc = cfTrace["loc"]?.uppercase(Locale.US)
            val cfDnsLoc = cfDnsTrace["loc"]?.uppercase(Locale.US)
            val dnsLeakOk = rawCode != null &&
                rawCode != "IR" &&
                (cfLoc == null || cfLoc != "IR") &&
                (cfDnsLoc == null || cfDnsLoc != "IR") &&
                !exitIp.isNullOrBlank()

            // 3. Balanced Download Speed test (256 KB via Cloudflare CDN)
            val downloadMbps = measureDownloadSpeedMbps(client)

            // 4. Strict Service Checks (Gemini + Telegram)
            val geminiOk = checkGemini(client, rawCode)
            val telegramOk = checkTelegram(client)

            // Balanced verification: require Gemini + DNS Leak + non-blocked country + real throughput
            // Don't discard a working Gemini server just because Spotify or YouTube flaked.
            val strictVerified = delayMs > 0L &&
                downloadMbps >= 0.15 &&
                dnsLeakOk &&
                geminiOk &&
                rawCode != null &&
                rawCode !in GEMINI_BLOCKED_COUNTRIES

            ServerAffiliationInfo(
                testDelayMillis = delayMs,
                countryCode = rawCode,
                countryName = countryName,
                exitIp = exitIp,
                downloadMbps = downloadMbps,
                dnsLeakOk = dnsLeakOk,
                geminiOk = geminiOk,
                telegramOk = telegramOk,
                strictVerified = strictVerified,
                isWarp = isWarp,
                lastAuditTime = now
            )
        } catch (e: Throwable) {
            LogUtil.e(AppConfig.TAG, "Strict audit failed for $guid", e)
            ServerAffiliationInfo(testDelayMillis = -1L, lastAuditTime = now)
        } finally {
            runCatching {
                if (controller.isRunning) {
                    controller.stopLoop()
                }
            }
        }
    }

    private fun allocateFreePort(): Int = try {
        ServerSocket(0).use { it.localPort }
    } catch (_: Exception) {
        -1
    }

    private fun injectAuditSocksAndDns(rawJson: String, port: Int): String? {
        return try {
            val root = JsonParser.parseString(rawJson).asJsonObject
            val socksInbound = JsonObject().apply {
                addProperty("tag", "audit-socks")
                addProperty("listen", "127.0.0.1")
                addProperty("port", port)
                addProperty("protocol", "socks")
                add("settings", JsonObject().apply {
                    addProperty("auth", "noauth")
                    addProperty("udp", true)
                })
                add("sniffing", JsonObject().apply {
                    addProperty("enabled", true)
                    add("destOverride", JsonArray().apply {
                        add("http")
                        add("tls")
                        add("quic")
                    })
                })
            }
            root.add("inbounds", JsonArray().apply { add(socksInbound) })
            root.add("dns", JsonObject().apply {
                add("servers", JsonArray().apply {
                    add("1.1.1.1")
                    add("8.8.8.8")
                })
            })
            root.toString()
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Failed to patch audit config", e)
            null
        }
    }

    private fun measureHttpLatency(client: OkHttpClient, url: String): Long {
        return try {
            val start = System.currentTimeMillis()
            val req = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (resp.code in 200..399) {
                    (System.currentTimeMillis() - start).coerceAtLeast(1L)
                } else {
                    -1L
                }
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun fetchCloudflareTrace(client: OkHttpClient, url: String): Map<String, String> {
        return try {
            val req = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyMap()
                val body = resp.body?.string().orEmpty()
                body.lineSequence()
                    .mapNotNull { line ->
                        val idx = line.indexOf('=')
                        if (idx > 0) line.substring(0, idx).trim() to line.substring(idx + 1).trim()
                        else null
                    }
                    .toMap()
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun fetchGeoIp(client: OkHttpClient): IPAPIInfo? {
        return try {
            val req = Request.Builder().url(AppConfig.IP_API_URL).header("User-Agent", USER_AGENT).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty()
                JsonUtil.fromJsonSafe(body, IPAPIInfo::class.java)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun measureDownloadSpeedMbps(client: OkHttpClient): Double {
        return try {
            val req = Request.Builder()
                .url("https://speed.cloudflare.com/__down?bytes=262144")
                .header("User-Agent", USER_AGENT)
                .build()
            val start = System.currentTimeMillis()
            var totalBytes = 0L
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return 0.0
                val stream = resp.body?.byteStream() ?: return 0.0
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val read = stream.read(buf)
                    if (read == -1) break
                    totalBytes += read
                }
            }
            val elapsedMs = (System.currentTimeMillis() - start).coerceAtLeast(1L)
            if (totalBytes <= 0L) 0.0 else (totalBytes * 8.0) / (elapsedMs * 1000.0)
        } catch (_: Exception) {
            0.0
        }
    }

    private fun checkGemini(client: OkHttpClient, countryCode: String?): Boolean {
        if (countryCode != null && countryCode in GEMINI_BLOCKED_COUNTRIES) return false
        val urlsToCheck = listOf(
            "https://gemini.google.com/",
            "https://gemini.google.com/app",
            "https://aistudio.google.com/"
        )
        for (targetUrl in urlsToCheck) {
            val ok = try {
                val req = Request.Builder()
                    .url(targetUrl)
                    .header("User-Agent", USER_AGENT)
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .build()
                client.newCall(req).execute().use { resp ->
                    val finalUrl = resp.request.url.toString().lowercase(Locale.US)
                    if (resp.code == 403 || resp.code == 429 || resp.code >= 500) return false
                    if (finalUrl.contains("unsupported") || finalUrl.contains("/sorry")) return false
                    val body = resp.body?.string()?.lowercase(Locale.US).orEmpty()
                    if (body.contains("isn't currently supported") ||
                        body.contains("isn&#39;t currently supported") ||
                        body.contains("isnt currently supported") ||
                        body.contains("not currently supported") ||
                        body.contains("not available in your country") ||
                        body.contains("detected unusual traffic") ||
                        body.contains("country_not_supported") ||
                        body.contains("unsupported_country")
                    ) {
                        return false
                    }
                    resp.code in 200..399
                }
            } catch (_: Exception) {
                false
            }
            if (!ok) return false
        }
        // Lightweight Google Gemini API geo-check (no JS needed):
        // Allowed IPs return 400/403 "API key" error; geo-blocked IPs return "location is not supported".
        val apiGeoOk = try {
            val apiReq = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models")
                .header("User-Agent", USER_AGENT)
                .build()
            client.newCall(apiReq).execute().use { resp ->
                val body = resp.body?.string()?.lowercase(Locale.US).orEmpty()
                !body.contains("location is not supported") &&
                    !body.contains("failed_precondition") &&
                    !body.contains("not available in your country")
            }
        } catch (_: Exception) {
            true // Don't falsely reject on transient network blip
        }
        return apiGeoOk
    }

    private fun checkTelegram(client: OkHttpClient): Boolean {
        return try {
            val apiReq = Request.Builder()
                .url("https://api.telegram.org/")
                .header("User-Agent", USER_AGENT)
                .build()
            val apiOk = client.newCall(apiReq).execute().use { resp ->
                resp.code in 200..499
            }
            if (!apiOk) return false
            val webReq = Request.Builder()
                .url("https://t.me/")
                .header("User-Agent", USER_AGENT)
                .build()
            client.newCall(webReq).execute().use { resp ->
                resp.code in 200..399
            }
        } catch (_: Exception) {
            false
        }
    }

    fun countryFlag(countryCode: String?): String {
        val code = countryCode?.trim()?.uppercase(Locale.US) ?: return "🌐"
        if (code.length != 2 || code.any { it !in 'A'..'Z' }) return "🌐"
        val first = Character.codePointAt(code, 0) - 0x41 + 0x1F1E6
        val second = Character.codePointAt(code, 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(first)) + String(Character.toChars(second))
    }

    fun countryDisplayName(countryCode: String?): String {
        val code = countryCode?.trim()?.uppercase(Locale.US) ?: return "Unknown"
        return Locale("", code).getDisplayCountry(Locale.ENGLISH).ifBlank { code }
    }
}
