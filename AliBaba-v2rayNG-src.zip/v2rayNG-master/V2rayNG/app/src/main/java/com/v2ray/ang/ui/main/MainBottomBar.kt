package com.v2ray.ang.ui.main

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.colorFabActive
import com.v2ray.ang.ui.compose.colorFabInactiveDark
import com.v2ray.ang.ui.compose.colorFabInactiveLight
import kotlinx.coroutines.launch

private val KNOB_SIZE = 56.dp
private val BAR_MAX_WIDTH = 480.dp
private const val TEXT_MAX_SP = 14f
private const val TEXT_MIN_SP = 10f
private const val TEXT_LINE_HEIGHT_FACTOR = 1.3f

/**
 * Connection status bar: a rounded track with the status message and the round connect button.
 *
 * The button always sits on the physical right edge, in left-to-right and right-to-left languages
 * alike, and never moves, so the bar can be used with one hand. The message is start-aligned (left
 * in LTR, right in RTL, next to the button). Tapping the track tests the current server. On wide
 * screens the bar is capped at [BAR_MAX_WIDTH] and centered.
 */
@Composable
fun MainBottomBar(
    displayText: String,
    isRunning: Boolean,
    isDarkTheme: Boolean,
    onAction: (MainAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val rotationAnim = remember { Animatable(0f) }
    val textLayoutDirection = LocalLayoutDirection.current

    LaunchedEffect(isRunning) {
        if (!isRunning) {
            rotationAnim.snapTo(0f)
        }
    }

    // The track is tall enough for two lines of text at the largest size (at the current font scale), so
    // its height is the same whether the message takes one line or two, in every language.
    val twoLinesHeight = with(LocalDensity.current) {
        (TEXT_MAX_SP * TEXT_LINE_HEIGHT_FACTOR * 2).sp.toDp()
    }
    val trackHeight = maxOf(KNOB_SIZE + 4.dp, twoLinesHeight + 20.dp)
    val knobInset = (trackHeight - KNOB_SIZE) / 2

    Box(
        modifier = modifier
            // On wide screens (tablets, landscape) the bar keeps a phone-like width and stays centered
            // instead of stretching across the whole screen.
            .widthIn(max = BAR_MAX_WIDTH)
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 14.dp)
    ) {
        // Forced left-to-right so that the button stays on the physical right edge in every language;
        // the message below gets the real layout direction back.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(trackHeight),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT: Separate Smart Connect button
                Box(
                    modifier = Modifier
                        .height(trackHeight)
                        .shadow(elevation = 4.dp, shape = CircleShape)
                        .clip(CircleShape)
                        .background(Color(0xFF2B210B))
                        .border(BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary), CircleShape)
                        .clickable { onAction(MainAction.SmartConnect) }
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "⚡ Smart",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1
                        )
                        Text(
                            text = "Connect",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFDE68A),
                            maxLines = 1
                        )
                    }
                }

                // RIGHT: Separate Connect / Disconnect & Status button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(trackHeight)
                ) {
                    val trackBg = if (isRunning) Color(0xFF064E3B) else MaterialTheme.colorScheme.surfaceContainerHigh
                    val trackBorder = if (isRunning) Color(0xFF10B981) else MaterialTheme.colorScheme.outlineVariant
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .shadow(elevation = if (isRunning) 8.dp else 3.dp, shape = CircleShape)
                            .clip(CircleShape)
                            .background(trackBg)
                            .border(BorderStroke(if (isRunning) 1.5.dp else 1.dp, trackBorder), CircleShape)
                            .clickable(onClick = { onAction(MainAction.TestCurrentServer) })
                    )
                    CompositionLocalProvider(LocalLayoutDirection provides textLayoutDirection) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .fillMaxWidth()
                                .absolutePadding(left = 14.dp, right = KNOB_SIZE + knobInset + 6.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            var fontSizeSp by remember(displayText) { mutableFloatStateOf(12.5f) }
                            val statusDot = if (isRunning) "● " else "○ "
                            Text(
                                text = statusDot + displayText,
                                color = if (isRunning) Color(0xFFECFDF5) else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = fontSizeSp.sp,
                                    fontWeight = if (isRunning) FontWeight.SemiBold else FontWeight.Normal,
                                    lineHeight = (fontSizeSp * TEXT_LINE_HEIGHT_FACTOR).sp,
                                    lineHeightStyle = LineHeightStyle(
                                        alignment = LineHeightStyle.Alignment.Center,
                                        trim = LineHeightStyle.Trim.None
                                    )
                                ),
                                textAlign = TextAlign.Start,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                onTextLayout = { layout ->
                                    if (layout.hasVisualOverflow && fontSizeSp > TEXT_MIN_SP) {
                                        fontSizeSp = (fontSizeSp - 1f).coerceAtLeast(TEXT_MIN_SP)
                                    }
                                },
                                modifier = Modifier.semantics { contentDescription = displayText }
                            )
                        }
                    }
                    FloatingActionButton(
                        onClick = {
                            if (!isRunning) {
                                scope.launch {
                                    rotationAnim.animateTo(
                                        targetValue = 720f,
                                        animationSpec = tween(durationMillis = 3000)
                                    )
                                }
                            }
                            onAction(MainAction.ToggleService)
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = knobInset)
                            .size(KNOB_SIZE),
                        shape = CircleShape,
                        containerColor = if (isRunning) Color(0xFF10B981)
                        else MaterialTheme.colorScheme.primary
                    ) {
                        Icon(
                            painter = if (isRunning) painterResource(R.drawable.ic_stop_24dp)
                            else painterResource(R.drawable.ic_play_24dp),
                            contentDescription = stringResource(
                                if (isRunning) R.string.acc_stop else R.string.acc_start
                            ),
                            tint = if (isRunning) Color.White else MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier
                                .size(24.dp)
                                .graphicsLayer { rotationZ = rotationAnim.value }
                        )
                    }
                }
            }
        }
    }
}
